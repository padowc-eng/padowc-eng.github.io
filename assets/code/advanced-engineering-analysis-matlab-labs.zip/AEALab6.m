%AEA Lab 6
%Problem 2
%Pl
%Constants
a = .5;
h = 1;
L = 1;
t_plot = [.1, .3, .6, .9];

x = linspace(0,L,1000);
eigenvals = zeros(1,10);
coeffs = zeros(1,10);

for n = 1:10
    eigenvals(n) = (n*pi/L)^2;
    coeffs(n) = (2*h*L^2* sin(n*pi*a/L)) /  (a*(L-a)*(n*pi)^2); %
end

figure;
hold on;

for p = 1:4
    sum = zeros(size(x));

    for i = 1:10
        eigenfunc = coeffs(i)*sin(sqrt(eigenvals(i))*x) *  cos(sqrt(eigenvals(i)) * t_plot(p));
        sum = sum + eigenfunc;
    end

    plot(x,sum,'DisplayName',sprintf('t = %.1f',t_plot(p)));
end

xlabel('x');
ylabel('u(x,t)');
title('Wave Equation 10 Term Sum');
legend();
grid on;
hold off;