#!/usr/bin/env python3
"""Pi motor worker for the Waveshare HR8825 Stepper HAT (B).

The two STEP pins use ONE synchronized lgpio wave instead of independent
PWM queues. The laptop streams STOP on SSH stdin; losing stdin fails closed.
The stop is a software stop, NOT a physical emergency-stop circuit.

No encoder feedback: a reported position is commanded steps, not measured
shaft position. If a run is interrupted, re-home before continuing.
"""
from __future__ import annotations
import argparse
import json
import sys
import threading
import time
from collections import namedtuple
from pathlib import Path
# Imported as part of the laptop package for tests; copied flat to the Pi for jobs.
try:
    from .motion_plan import RatePlanner, estimate_seconds, estimate_pen_seconds
except ImportError:
    from motion_plan import RatePlanner, estimate_seconds, estimate_pen_seconds

# BCM DIR, STEP, ENABLE. On HAT(B), Pi ENABLE is active high (inverted on board).
# Servo uses a separate free BCM GPIO and an external regulated 5V supply.
PINS = ((13, 19, 12), (24, 18, 4))
STEP_GROUP = (19, 18)
STEP_LEADER = STEP_GROUP[0]
STEP_MASK = 0b11
Pulse = namedtuple('Pulse', 'group_bits group_mask pulse_delay')


def report(**kwargs):
    print(json.dumps(kwargs, separators=(',', ':')), flush=True)


def make_step_wave(before, target, start, end, count, duration):
    """DDA/Bresenham step decisions for each motor, synchronized in time.

    Each tick occupies an approximately equal part of the planner's chunk.
    Group bits use GPIO group ORDER (19 = bit 0, 18 = bit 1), NOT BCM numbers.
    """
    ticks = end - start
    if ticks <= 0:
        return [], (0, 0), 0.0
    d = (abs(int(target[0]) - int(before[0])),
         abs(int(target[1]) - int(before[1])))
    if count <= 0 or max(d) != count:
        raise ValueError('Invalid DDA segment')
    us = max(40, round(float(duration) * 1_000_000 / ticks))
    high = 8
    low = us - high
    waves = []
    totals = [0, 0]
    for tick in range(start, end):
        bits = 0
        for axis in (0, 1):
            if ((tick + 1) * d[axis]) // count > (tick * d[axis]) // count:
                bits |= (1 << axis)
                totals[axis] += 1
        # Every tick has a falling edge and low period, even when an axis idles.
        # Do NOT claim any pins besides GPIO 19 and 18 as part of this group.
        waves.append(Pulse(bits, STEP_MASK, high))
        waves.append(Pulse(0, STEP_MASK, low))
    return waves, tuple(totals), ticks * us / 1_000_000.0


class PenServo:
    """Hobby-servo pen lift on a GPIO separate from the HAT STEP group.

    A nominal 500 us pulse-width change is approximately 90 degrees for many
    servos, but actual angle MUST be calibrated with the servo horn detached.
    """
    def __init__(self, lg, handle, settings, simulate=False):
        self.lg = lg
        self.h = handle
        self.simulate = simulate
        self.enabled = bool(settings.get('enabled', False))
        self.pin = int(settings.get('gpio', 23))
        self.up_us = int(settings.get('up_us', 1500))
        self.down_us = int(settings.get('down_us', 2000))
        self.settle_s = float(settings.get('settle_s', 0.45))
        self.pen_down = None
        self.transition_count = 0
        # A continuous software PWM signal can make a hobby servo twitch.
        # In burst mode it receives a short, finite positioning pulse train.
        # With no subsequent pulses the servo cannot actively hold torque.
        self.hold_pwm = bool(settings.get('hold_pwm', False))
        self.pulse_cycles = int(settings.get('pulse_cycles', 30))
        if not 10 <= self.pulse_cycles <= 100:
            raise ValueError('Servo pulse_cycles must be 10..100')
        if not self.enabled:
            return
        used = {p for axis in PINS for p in axis} | {16, 17, 20, 21, 22, 27}
        if self.pin in used or not 2 <= self.pin <= 27:
            raise ValueError('Servo GPIO conflicts with HAT or is out of range')
        if not (900 <= self.up_us <= 2100 and 900 <= self.down_us <= 2100):
            raise ValueError('Servo pulse widths must be 900-2100 us')
        if self.up_us == self.down_us:
            raise ValueError('Pen up/down servo positions must differ')
        if not 0.10 <= self.settle_s <= 2.5:
            raise ValueError('Servo settling time must be 0.10-2.5 s')
        if not simulate:
            lg.gpio_claim_output(handle, self.pin, 0)

    def set_pen(self, down, stop_event=None, force=False):
        if not self.enabled:
            return False
        down = bool(down)
        if self.pen_down is down and not force:
            return False
        width = self.down_us if down else self.up_us
        # Finite servo pulse burst prevents timing jitter during long strokes.
        # It must finish before the next GPIO group wave begins.
        if not self.simulate:
            if self.hold_pwm:
                self.lg.tx_servo(self.h, self.pin, width, 50)
            else:
                self.lg.tx_servo(self.h, self.pin, width, 50, 0,
                                 self.pulse_cycles)
        self.pen_down = down
        self.transition_count += 1
        # In burst mode ensure all finite pulses have elapsed before resuming
        # stepper waves. A later pen command then won't queue behind this one.
        pause = max(self.settle_s,
                    self.pulse_cycles / 50.0 + 0.06) if not self.hold_pwm else self.settle_s
        if stop_event is not None:
            if stop_event.wait(pause):
                raise InterruptedError('Stopped while moving pen servo')
        else:
            time.sleep(pause)
        return True

    def close(self):
        if self.enabled and self.h is not None and not self.simulate:
            # lgpio documents zero pulse width as servo OFF (not zero PWM
            # micros on tx_pulse).  In finite mode this is already stopped.
            if self.hold_pwm:
                self.lg.tx_servo(self.h, self.pin, 0, 50)


class Pair:
    def __init__(self, simulate=False, servo_settings=None):
        self.simulate = simulate
        self.pos = [0, 0]
        self.lg = None
        self.h = None
        self.stop_event = threading.Event()
        self.stop_reason = None
        self.lock = threading.RLock()
        self.driver_enabled = False
        self.servo = PenServo(None, None, servo_settings or {}, simulate=True) if simulate else None
        if not simulate:
            import lgpio
            self.lg = lgpio
            self.h = lgpio.gpiochip_open(0)
            try:
                for direction, _, enable in PINS:
                    lgpio.gpio_claim_output(self.h, direction, 0)
                    lgpio.gpio_claim_output(self.h, enable, 0)
                lgpio.group_claim_output(self.h, list(STEP_GROUP), [0, 0])
                self.servo = PenServo(lgpio, self.h, servo_settings or {})
            except Exception:
                lgpio.gpiochip_close(self.h)
                self.h = None
                raise

    def enabled(self, on):
        with self.lock:
            if self.stop_event.is_set() and on:
                return
            self.driver_enabled = bool(on)
            if self.h is not None:
                for _, _, enable in PINS:
                    self.lg.gpio_write(self.h, enable, int(on))

    def stop_now(self, reason='Stop requested'):
        if self.stop_reason is None:
            self.stop_reason = reason
        self.stop_event.set()
        # Immediately disable drivers even if a wave is still winding down.
        self.enabled(False)

    def move(self, target, pen, planner, progress):
        # Change pen state BEFORE starting axis motion. Keep one pen-down state
        # for the entire continuous traced stroke; no toggling per waypoint.
        if self.stop_event.is_set():
            raise InterruptedError('Stop requested')
        if self.servo is not None and self.servo.set_pen(pen, self.stop_event):
            report(type='servo', pen=bool(pen),
                   transitions=self.servo.transition_count,
                   detail='Pen down' if pen else 'Pen up')
            report(type='position', steps=self.pos, pen=bool(pen),
                   detail='Pen down' if pen else 'Pen up')
        before = self.pos[:]
        target = [int(target[0]), int(target[1])]
        delta = [target[i] - before[i] for i in (0, 1)]
        count = max(abs(delta[0]), abs(delta[1]))
        if count > 50000:
            raise ValueError('Move exceeds 50000 microsteps')
        if self.stop_event.is_set():
            raise InterruptedError('Stop requested')
        if count:
            if self.lg:
                for i, (direction, _, _) in enumerate(PINS):
                    self.lg.gpio_write(self.h, direction, int(delta[i] < 0))
            self.enabled(True)
            if self.stop_event.wait(0.001):
                raise InterruptedError('Stop requested')

        start = 0
        for end, total, axis_counts, duration in planner.segment(before, target, pen):
            if self.stop_event.is_set():
                raise InterruptedError('Stop requested')
            wave, generated_counts, actual_duration = make_step_wave(
                before, target, start, end, count, duration)
            if generated_counts != tuple(axis_counts):
                raise RuntimeError('Internal DDA count mismatch')
            if self.lg:
                # Single group wave: no race between independent PWM queues.
                self.lg.tx_wave(self.h, STEP_LEADER, wave)
                # Finite, duration-aware watchdog. The original 0.75s timeout
                # was susceptible to scheduler jitter; don't label it HAT power.
                timeout = max(2.0, actual_duration * 5.0 + 1.0)
                deadline = time.monotonic() + timeout
                next_heartbeat = time.monotonic() + 0.35
                while self.lg.tx_busy(self.h, STEP_LEADER, self.lg.TX_WAVE):
                    if self.stop_event.wait(0.005):
                        raise InterruptedError('Stop requested')
                    now = time.monotonic()
                    if now > deadline:
                        self.stop_now('GPIO synchronized wave timeout')
                        raise RuntimeError(
                            f'GPIO wave did not finish within {timeout:.2f}s '
                            f'(expected {actual_duration:.3f}s). '
                            'Possible lgpio scheduler conflict or overloaded Pi.')
                    if now >= next_heartbeat:
                        report(type='heartbeat', steps=self.pos,
                               detail='Pi GPIO wave in progress',
                               expected_chunk_s=round(actual_duration, 3))
                        next_heartbeat = now + .35
            elif self.stop_event.wait(actual_duration):
                raise InterruptedError('Stop requested')
            self.pos = [before[i] + (1 if delta[i] >= 0 else -1) *
                        ((end * abs(delta[i])) // total) for i in (0, 1)]
            progress()
            start = end

    def close(self):
        # On finish or STOP, disable motor drivers immediately, then retract
        # marker and release the servo PWM before releasing the GPIO chip.
        self.stop_now()
        try:
            if self.servo is not None:
                try:
                    self.servo.set_pen(False)
                finally:
                    self.servo.close()
        finally:
            if self.h is not None:
                try:
                    # Wait only briefly for a wave already in flight.
                    deadline = time.monotonic() + .4
                    while time.monotonic() < deadline and self.lg.tx_busy(
                            self.h, STEP_LEADER, self.lg.TX_WAVE):
                        time.sleep(.003)
                finally:
                    self.lg.gpiochip_close(self.h)
                    self.h = None


def run(job_file, stop_file, simulate=False):
    job = json.loads(job_file.read_text(encoding='utf-8'))
    moves = job['moves']
    if len(moves) > 60000:
        raise ValueError('Job exceeds 60000 points')
    for i, row in enumerate(moves):
        if len(row) != 5 or max(abs(row[0]), abs(row[1])) > 200000:
            raise ValueError(f'Unsafe motor target at point {i}')
    rate = max(250, min(2200, int(job.get('max_rate', 1200))))
    settings = {k: job[k] for k in ('accel','jerk','max_centripetal',
                  'detail_radius','detail_factor','travel_factor',
                  'junction_dev','chunk') if k in job}
    planner = RatePlanner(rate, **settings)
    planner.prepare(moves)
    pair = Pair(simulate, job.get('servo', {}))

    def commands():
        while True:
            try:
                line = sys.stdin.readline()
            except (OSError, ValueError):
                pair.stop_now('SSH control input failed; fail-safe stop')
                return
            if not line:
                pair.stop_now('SSH input closed; fail-safe stop')
                return
            if line.strip().upper() == 'STOP':
                pair.stop_now('STOP received from laptop')
                return
    threading.Thread(target=commands, daemon=True).start()
    last_report = 0.0
    total = len(moves)
    started = time.monotonic()
    report(type='started', total=total, steps=pair.pos, simulate=simulate,
           estimate=estimate_seconds(moves, rate, **settings) +
           estimate_pen_seconds(moves,
              job.get('servo', {}).get('settle_s', .45),
              job.get('servo', {}).get('enabled', False)), rate=rate)
    try:
        # Start every job with the marker physically UP.
        if pair.servo is not None and pair.servo.set_pen(False, pair.stop_event):
            report(type='servo', pen=False,
                   transitions=pair.servo.transition_count,
                   detail='Pen up / ready')
            report(type='position', steps=pair.pos, pen=False,
                   completed=0, total=total, detail='Pen up / ready')
        for i, (a, b, pen, x, y) in enumerate(moves):
            if stop_file.exists():
                pair.stop_now('Remote stop flag detected')
            if pair.stop_event.is_set():
                raise InterruptedError('Stop requested')
            def progress():
                nonlocal last_report
                now = time.monotonic()
                if now - last_report >= .035:
                    report(type='position', steps=pair.pos, pen=bool(pen),
                           completed=i, total=total, elapsed=now-started)
                    last_report = now
            try:
                pair.move((a, b), bool(pen), planner, progress)
            except Exception as exc:
                if not isinstance(exc, InterruptedError):
                    raise RuntimeError(f'At waypoint {i+1}/{total}, '
                                       f'last step counts {pair.pos}: {exc}') from exc
                raise
            progress()
        if pair.servo is not None and pair.servo.set_pen(False, pair.stop_event):
            report(type='servo', pen=False,
                   transitions=pair.servo.transition_count, detail='Pen up / finished')
        report(type='position', steps=pair.pos, pen=False,
               completed=total, total=total, elapsed=time.monotonic()-started)
        report(type='finished', steps=pair.pos, completed=total, total=total)
    except InterruptedError:
        report(type='stopped', steps=pair.pos,
               reason=pair.stop_reason or 'Motion interrupted',
               elapsed=time.monotonic()-started)
    finally:
        pair.close()
        try:
            stop_file.unlink(missing_ok=True)
        except OSError:
            pass


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', type=Path, required=True)
    parser.add_argument('--stop', type=Path, required=True)
    parser.add_argument('--simulate', action='store_true')
    args = parser.parse_args()
    try:
        run(args.job, args.stop, args.simulate)
    except Exception as exc:
        report(type='error', message=f'{type(exc).__name__}: {exc}')
        raise SystemExit(1)
