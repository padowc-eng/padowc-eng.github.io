"""Trace skeleton graphs as few pen-down strokes as possible.

1. Pair broken endpoints only when distance and outgoing tangents agree.
2. Trace the entire connected skeleton component as one continuous route.
3. For branched shapes, duplicate only the shortest connecting graph paths
   needed to produce an Euler traversal (may redraw some branch sections).

Disconnected components correctly remain separate pen-down operations.
"""
from __future__ import annotations
import heapq
import math
import cv2
import numpy as np

SHIFTS = ((-1, 0), (1, 0), (0, -1), (0, 1),
          (-1, -1), (-1, 1), (1, -1), (1, 1))


def _graph(mask):
    ys, xs = np.nonzero(mask)
    pix = {(int(x), int(y)) for x, y in zip(xs, ys)}
    adjacency = {}
    for x, y in pix:
        p = (x, y)
        nn = []
        for dx, dy in SHIFTS:
            q = (x + dx, y + dy)
            if q not in pix:
                continue
            if dx and dy and ((x + dx, y) in pix or (x, y + dy) in pix):
                continue
            nn.append(q)
        adjacency[p] = nn
    return adjacency


def _components(adj):
    remaining = set(adj)
    while remaining:
        source = next(iter(remaining))
        remaining.remove(source)
        comp = {source}
        stack = [source]
        while stack:
            for q in adj[stack.pop()]:
                if q in remaining:
                    remaining.remove(q)
                    comp.add(q)
                    stack.append(q)
        yield comp


def _tip_direction(point, adj, length=5):
    """Unit tangent OUT of the existing stroke at a degree-1 endpoint."""
    current = point
    previous = None
    for _ in range(length):
        nexts = [q for q in adj[current] if q != previous]
        if len(nexts) != 1:
            break
        previous, current = current, nexts[0]
    dx, dy = point[0] - current[0], point[1] - current[1]
    mag = math.hypot(dx, dy)
    return (dx / mag, dy / mag) if mag else None


def repair_skeleton_gaps(skeleton, gap_px=6, min_alignment=0.52):
    """Bridge short, nearly tangential endpoint gaps; no indiscriminate dilation.

    Each endpoint is used at most once.  A gap is not joined just because two
    branches are spatially close; both endpoint tangents must point across it.
    """
    result = np.uint8(skeleton > 0) * 255
    gap_px = int(gap_px)
    if gap_px <= 0:
        return result, 0
    adj = _graph(result)
    ends = [p for p, neighbors in adj.items() if len(neighbors) == 1]
    tangents = {p: _tip_direction(p, adj) for p in ends}
    # Spatial hash avoids quadratic searches on text-heavy logos.
    tile = max(2, gap_px)
    buckets = {}
    for p in ends:
        buckets.setdefault((p[0] // tile, p[1] // tile), []).append(p)
    candidates = []
    for p in ends:
        if tangents[p] is None:
            continue
        cx, cy = p[0] // tile, p[1] // tile
        for gx in range(cx - 1, cx + 2):
            for gy in range(cy - 1, cy + 2):
                for q in buckets.get((gx, gy), ()):
                    if q <= p or tangents[q] is None:
                        continue
                    dx, dy = q[0] - p[0], q[1] - p[1]
                    distance = math.hypot(dx, dy)
                    if not (1.5 <= distance <= gap_px):
                        continue
                    ux, uy = dx / distance, dy / distance
                    a = tangents[p][0] * ux + tangents[p][1] * uy
                    b = -(tangents[q][0] * ux + tangents[q][1] * uy)
                    if min(a, b) < min_alignment:
                        continue
                    # Prefer a close bridge that aligns with BOTH stroke ends.
                    cost = distance / max(0.1, (a + b) / 2)
                    candidates.append((cost, p, q))
    used = set()
    joins = 0
    for _, p, q in sorted(candidates):
        if p in used or q in used:
            continue
        # Prevent a short bridge cutting through a different skeleton stroke.
        temp = np.zeros_like(result)
        cv2.line(temp, p, q, 255, 1, cv2.LINE_8)
        ys, xs = np.nonzero(temp)
        crossed = False
        for x, y in zip(xs, ys):
            s = (int(x), int(y))
            if s != p and s != q and result[y, x]:
                crossed = True
                break
        if crossed:
            continue
        cv2.line(result, p, q, 255, 1, cv2.LINE_8)
        used.add(p)
        used.add(q)
        joins += 1
    return result, joins


def _edge(p, q):
    return (p, q) if p < q else (q, p)


def _score_continuation(prev, at, nxt):
    # Favor a tangent continuation at a crossing rather than jumping onto a
    # neighboring curve. At ordinary corners the only unused edge wins.
    ax, ay = at[0] - prev[0], at[1] - prev[1]
    bx, by = nxt[0] - at[0], nxt[1] - at[1]
    return (ax * bx + ay * by) / max(1e-12, math.hypot(ax, ay) * math.hypot(bx, by))


def _available(at, adjacency, remaining):
    return [q for q in adjacency[at] if _edge(at, q) in remaining]


def _walk(adjacency, remaining, start, first=None, allow_close=False):
    # Uses a private edge set: the caller only commits a successful route.
    edges = set(remaining)
    route = [start]
    prev = None
    cur = start
    if first is not None:
        if _edge(cur, first) not in edges:
            return route, False
        edges.remove(_edge(cur, first))
        route.append(first)
        prev, cur = cur, first
    while True:
        if cur == start and len(route) > 2:
            return route, True
        options = _available(cur, adjacency, edges)
        if not options:
            return route, False
        if prev is not None:
            # Prefer following the same stroke at crossings, not retracing.
            options.sort(key=lambda p: (_score_continuation(prev, cur, p), p), reverse=True)
        else:
            options.sort()
        nxt = options[0]
        edges.remove(_edge(cur, nxt))
        route.append(nxt)
        prev, cur = cur, nxt
        if len(route) > len(remaining) + 1:
            raise RuntimeError('Unexpected repeat in edge-disjoint traversal')


def _commit(route, remaining):
    for a, b in zip(route, route[1:]):
        e = _edge(a, b)
        if e not in remaining:
            raise RuntimeError('Attempted to redraw an already-used skeleton edge')
        remaining.remove(e)


def _signed_area(path):
    return .5 * sum(a[0] * b[1] - a[1] * b[0]
                      for a, b in zip(path, path[1:]))


def _minimal_non_repeating_trails(remaining):
    """Fewest pen-down trails for remaining original edges, with no redraw.

    Add VIRTUAL pairings of odd-degree vertices solely for route planning,
    find one Euler circuit, and split at those virtual edges. No virtual edge
    ever goes to the Pi. The number of real strokes is ceil(odd_count/2).
    """
    graph = {}
    for a,b in remaining:
        graph.setdefault(a,set()).add(b)
        graph.setdefault(b,set()).add(a)
    routes=[]
    unseen=set(graph)
    while unseen:
        root=min(unseen)
        comp={root}; stack=[root]; unseen.remove(root)
        while stack:
            for nxt in graph[stack.pop()]:
                if nxt in unseen:
                    unseen.remove(nxt);comp.add(nxt);stack.append(nxt)
        local=[(a,b,False) for a,b in sorted(remaining) if a in comp]
        degrees={p:len(graph[p]) for p in comp}
        odd=sorted(p for p in comp if degrees[p]%2)
        for a,b in zip(odd[::2],odd[1::2]):
            local.append((a,b,True))
        neighbors={p:[] for p in comp}
        for eid,(a,b,virtual) in enumerate(local):
            neighbors[a].append((b,eid))
            neighbors[b].append((a,eid))
        used=set()
        trail=[(min(comp),None)]
        backward=[]
        while trail:
            at=trail[-1][0]
            while neighbors[at] and neighbors[at][-1][1] in used:
                neighbors[at].pop()
            if neighbors[at]:
                nxt,eid=neighbors[at].pop()
                if eid in used:
                    continue
                used.add(eid)
                trail.append((nxt,eid))
            else:
                backward.append(trail.pop())
        backward.reverse()
        transitions=[(backward[i-1][0],backward[i][0],backward[i][1])
                     for i in range(1,len(backward))]
        if odd:
            pivot=next(i for i,(_,_,eid) in enumerate(transitions) if local[eid][2])
            transitions=transitions[pivot+1:]+transitions[:pivot+1]
        if not transitions:
            continue
        path=[transitions[0][0]]
        for a,b,eid in transitions:
            if local[eid][2]:
                if len(path)>1:
                    routes.append(path)
                path=[b]
            else:
                if path[-1]!=a:
                    raise RuntimeError('Broken continuous non-retracing trail')
                path.append(b)
        if len(path)>1:
            routes.append(path)
    return routes


def _trace_edge_disjoint(adj, comp, min_length):
    """Draw each skeleton edge at most once. Closed loops get first priority.

    Unlike the old Chinese-postman/Eulerization routine, this never inserts
    repeated edges into a drawing. A connected T/branch may necessarily use
    more than one pen-down stroke: zero retracing and a single stroke are
    mathematically incompatible for some branched graphs.
    """
    remaining = {_edge(p, q) for p in comp for q in adj[p] if q in comp}
    routes = []
    loops = 0
    # Find dominant rings ahead of spurs/crossbars; the obvious logo outline
    # stays one closed stroke even if other lines branch from its boundary.
    # Candidates favor degree-2 pixels along long lines, plus junctions if a
    # component consists entirely of junctions (rare at normal raster scale).
    while remaining:
        active = {p for edge in remaining for p in edge}
        candidates = [p for p in sorted(active)
                      if len(_available(p, adj, remaining)) == 2]
        if not candidates:
            candidates = sorted(active)
        # Cover spatially diverse choices and avoid repeated exhaustive walks.
        candidates = candidates[::max(1, len(candidates)//22)][:24]
        best = None
        best_metric = -1
        for p in candidates:
            for q in _available(p, adj, remaining):
                cycle, closed = _walk(adj, remaining, p, q, allow_close=True)
                if not closed or len(cycle) < 12:
                    continue
                length = sum(math.dist(a, b) for a,b in zip(cycle,cycle[1:]))
                area = abs(_signed_area(cycle))
                if length < max(12, 2*min_length) or area < max(16, min_length**2):
                    continue
                # Prefer substantial simple contours to tiny raster loops.
                metric = length + math.sqrt(area)
                if metric > best_metric:
                    best = cycle
                    best_metric = metric
        if best is None:
            break
        _commit(best, remaining)
        routes.append(best)
        loops += 1
        if loops >= 75:  # protect against noise-heavy raster adversarial cases
            break

    # Exactly minimal remaining pen-down strokes without any drawn edge twice.
    if remaining:
        routes.extend(_minimal_non_repeating_trails(remaining))

    good = [p for p in routes if sum(math.dist(a,b) for a,b in zip(p,p[1:])) >= min_length]
    return good, loops


def continuous_skeleton_paths(skeleton, min_length=8, gap_px=6):
    repaired, joins = repair_skeleton_gaps(skeleton, gap_px)
    adj = _graph(repaired)
    paths = []
    loops = 0
    for comp in _components(adj):
        if len(comp) < 3:
            continue
        routes, nloops = _trace_edge_disjoint(adj, comp, min_length)
        paths.extend(routes)
        loops += nloops
    paths.sort(key=lambda p: sum(math.dist(a,b) for a,b in zip(p,p[1:])), reverse=True)
    return paths, {'gap_repairs': joins, 'connected_strokes': len(paths),
                   'retraced_pixel_edges': 0, 'closed_loops': loops}
