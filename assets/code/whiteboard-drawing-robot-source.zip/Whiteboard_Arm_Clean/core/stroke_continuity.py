"""Recognize clean circular pen strokes and join tiny aligned breaks.

A perfect circle should not inherit dozens of pen lifts from raster noise.
The joins below are strictly local and tangent-checked: unrelated nearby marks
remain independent. All coordinates in stitch_paths() are board inches.
"""
from __future__ import annotations

import math
import cv2
import numpy as np


def recognize_circles(skeleton, min_radius_px=12, max_deviation_ratio=0.048):
    """Return ([closed-circle-polylines], remaining-skeleton, recognition count).

    Operates on the *already gap-repaired* one-pixel centerline. Each connected
    component must cover the full angular range and fit a nearly constant
    radius. Fitted circles are emitted once as smooth, explicitly closed
    curves and are excluded from generic graph tracing.
    """
    binary = np.uint8(skeleton > 0)
    n, labels, stats, centers = cv2.connectedComponentsWithStats(binary, 8)
    output=[]
    remaining=binary.copy()
    for component in range(1,n):
        area=int(stats[component,cv2.CC_STAT_AREA])
        if area < 55:
            continue
        yy,xx=np.nonzero(labels==component)
        if len(xx)<55:
            continue
        pts=np.column_stack((xx.astype(float), yy.astype(float)))
        # Algebraic least-squares circle; resistant to 1px antialiasing noise.
        x=pts[:,0]; y=pts[:,1]
        a=np.column_stack((2*x,2*y,np.ones_like(x)))
        b=x*x+y*y
        try:
            sol=np.linalg.lstsq(a,b,rcond=None)[0]
        except np.linalg.LinAlgError:
            continue
        cx,cy=float(sol[0]),float(sol[1])
        radius_sq=float(sol[2]+cx*cx+cy*cy)
        if radius_sq<=0:
            continue
        radius=math.sqrt(radius_sq)
        if not min_radius_px <= radius <= 0.65 * max(skeleton.shape):
            continue
        dist=np.hypot(x-cx,y-cy)
        err=np.abs(dist-radius)
        if (float(np.mean(err))> max(0.8,max_deviation_ratio*radius) or
            float(np.percentile(err,90)) > max(1.8,0.075*radius)):
            continue
        # Every 15-degree angular sector should contain at least one point;
        # allows small repaired gaps, but disallows disconnected arcs.
        angles=(np.arctan2(y-cy,x-cx)+2*math.pi)%(2*math.pi)
        hist,_=np.histogram(angles,bins=24,range=(0,2*math.pi))
        if np.count_nonzero(hist)<23:
            continue
        if not (0.65 * 2*math.pi*radius <= area <= 2.8 * 2*math.pi*radius):
            continue
        number=max(48,min(640,math.ceil(2*math.pi*radius/2.8)))
        path=[(cx+radius*math.cos(2*math.pi*i/number),
               cy+radius*math.sin(2*math.pi*i/number)) for i in range(number)]
        path.append(path[0])
        output.append(path)
        remaining[labels==component]=0
    return output, (remaining*255).astype(np.uint8), len(output)


def _distance(a,b):
    return math.hypot(a[0]-b[0], a[1]-b[1])


def _tangent(path, at_end, reach=0.14):
    """Direction forward into/out of an open polyline endpoint."""
    points=path[::-1] if at_end else path
    p=points[0]
    for q in points[1:]:
        if _distance(p,q)>=reach:
            vx,vy=p[0]-q[0],p[1]-q[1]
            d=math.hypot(vx,vy)
            return (vx/d,vy/d) if at_end else (-vx/d,-vy/d)
    q=points[-1]
    vx,vy=p[0]-q[0],p[1]-q[1]
    d=math.hypot(vx,vy)
    return ((vx/d,vy/d) if at_end else (-vx/d,-vy/d)) if d>1e-9 else None


def _closed(p):
    return len(p)>3 and _distance(p[0],p[-1])<0.018


def stitch_paths(paths, geometry, max_gap_in=0.15, min_alignment=0.30):
    """Join only open path ends with close, tangent-compatible near gaps.

    Near-coincident endpoints alone are insufficient: letters and symbols can
    be close but unrelated. Never join distinct closed loops. Never bridge
    outside the robot's reachable region. A joined gap becomes pen-DOWN travel.
    """
    paths=[list(map(tuple,p)) for p in paths if len(p)>=2]
    max_gap_in=max(0.,min(0.30,float(max_gap_in)))
    if not max_gap_in:
        return paths,0
    joins=0
    while True:
        best=None
        # Spatial hash avoids checking every pair in a complicated image.
        cells={}
        cell_size=max_gap_in
        for idx,p in enumerate(paths):
            if _closed(p):
                continue
            for endpoint in (p[0],p[-1]):
                cell=(math.floor(endpoint[0]/cell_size),
                      math.floor(endpoint[1]/cell_size))
                cells.setdefault(cell,set()).add(idx)
        # Only open strokes can be joined; preserve full circles and polygons.
        for i,raw_a in enumerate(paths):
            if _closed(raw_a):
                continue
            near={i}
            for point in (raw_a[0],raw_a[-1]):
                x,y=math.floor(point[0]/cell_size),math.floor(point[1]/cell_size)
                for dx in (-1,0,1):
                    for dy in (-1,0,1):
                        near.update(cells.get((x+dx,y+dy),()))
            for j in sorted(k for k in near if k>=i):
                if i==j:
                    variants=[(False,False)]
                else:
                    if _closed(paths[j]):
                        continue
                    variants=[(flip_a,flip_b) for flip_a in (False,True)
                              for flip_b in (False,True)]
                for flip_a,flip_b in variants:
                    a=raw_a[::-1] if flip_a else raw_a
                    b=paths[j][::-1] if flip_b else paths[j]
                    gap=_distance(a[-1],b[0])
                    if gap > max_gap_in:
                        continue
                    # Exact shared nodes are always continuous; otherwise
                    # require the two stroke tangents to align across the gap.
                    if gap <= 0.008:
                        if best is None or gap<best[0]:
                            best=(gap,i,j,flip_a,flip_b)
                        continue
                    # Never close an open line by jumping across a far region.
                    ta=_tangent(a,True)
                    tb=_tangent(b,False)
                    if ta is None or tb is None:
                        continue
                    vx=(b[0][0]-a[-1][0])/gap
                    vy=(b[0][1]-a[-1][1])/gap
                    # Check tangents of BOTH traces against the gap direction.
                    if (ta[0]*vx+ta[1]*vy < min_alignment or
                        tb[0]*vx+tb[1]*vy < min_alignment):
                        continue
                    if not all(geometry.valid(a[-1][0]+k*(b[0][0]-a[-1][0]),
                                              a[-1][1]+k*(b[0][1]-a[-1][1]),
                                              geometry.marker_diameter/2)
                               for k in (0.25,0.5,0.75)):
                        continue
                    if best is None or gap<best[0]:
                        best=(gap,i,j,flip_a,flip_b)
        if best is None:
            break
        _,i,j,fa,fb=best
        a=paths[i][::-1] if fa else paths[i]
        b=paths[j][::-1] if fb else paths[j]
        if i==j:
            paths[i]=a+[a[0]]
        else:
            paths[i]=a+(b[1:] if _distance(a[-1],b[0]) <= 0.008 else b)
            paths.pop(j)
        joins+=1
    return paths,joins


def recognize_ellipses(skeleton, max_deviation_ratio=0.05):
    """Fit isolated full elliptical rings; reject triangles and partial arcs.

    Uses the actual centerline, not outer/inner raster boundaries. A close fit
    with full angular coverage is required before replacing the raw pixels.
    """
    binary=np.uint8(skeleton>0)
    n,labels,stats,_=cv2.connectedComponentsWithStats(binary,8)
    output=[]
    remaining=binary.copy()
    for c in range(1,n):
        if stats[c,cv2.CC_STAT_AREA]<80:
            continue
        yy,xx=np.nonzero(labels==c)
        pts=np.column_stack((xx,yy)).astype(np.float32)
        if len(pts)<80:
            continue
        try:
            (cx,cy),(d1,d2),angle=cv2.fitEllipse(pts.reshape(-1,1,2))
        except cv2.error:
            continue
        a,b=d1/2,d2/2
        if min(a,b)<10 or max(a,b)>max(skeleton.shape)*0.7:
            continue
        if min(a,b)/max(a,b)<0.24:
            continue
        angle=math.radians(angle)
        co,si=math.cos(angle),math.sin(angle)
        dx=pts[:,0]-cx;dy=pts[:,1]-cy
        u=(co*dx+si*dy)/a
        v=(-si*dx+co*dy)/b
        err=np.abs(np.hypot(u,v)-1.)
        if float(np.mean(err))>max_deviation_ratio or float(np.percentile(err,90))>0.095:
            continue
        bins,_=np.histogram((np.arctan2(v,u)+2*math.pi)%(2*math.pi),
                            bins=24,range=(0,2*math.pi))
        if np.count_nonzero(bins)<23:
            continue
        circumference=math.pi*(3*(a+b)-math.sqrt((3*a+b)*(a+3*b)))
        if not 0.65*circumference<=len(pts)<=2.8*circumference:
            continue
        count=max(48,min(640,math.ceil(circumference/2.8)))
        path=[]
        for i in range(count):
            t=2*math.pi*i/count
            x=a*math.cos(t);y=b*math.sin(t)
            path.append((cx+co*x-si*y,cy+si*x+co*y))
        path.append(path[0])
        output.append(path)
        remaining[labels==c]=0
    return output, (remaining*255).astype(np.uint8),len(output)


def suppress_micro_lifts(moves, max_gap_in=0.06):
    """Suppress sub-marker travel gaps between TWO pen-down segments.

    Operates on the same move records used by preview and the Pi. The travel
    waypoints themselves are preserved, but pen flags are changed to DOWN when
    the ENTIRE intervening hop stays within the tolerance. Never suppress
    the initial approach or the final return-to-home lift.
    """
    data=[list(row) for row in moves]
    max_gap=max(0.,min(0.15,float(max_gap_in)))
    if max_gap<=0:
        return data,0
    suppressed=0
    i=0
    while i<len(data):
        if data[i][2]:
            i+=1
            continue
        j=i
        while j<len(data) and not data[j][2]:
            j+=1
        if i>0 and j<len(data) and data[i-1][2]:
            anchor=(data[i-1][3],data[i-1][4])
            destination=(data[j][3],data[j][4])
            if (_distance(anchor,destination)<=max_gap and
                all(_distance(anchor,(data[k][3],data[k][4]))<=max_gap
                    for k in range(i,j))):
                for k in range(i,j):
                    data[k][2]=True
                suppressed+=1
        i=j
    return data,suppressed
