# Whiteboard Arm — Clean Desktop Project (consolidated through v14)

This folder replaces the old v2 + thirteen separate patches. **Nothing needs to be
installed from those patch ZIPs again.** It preserves the current processing,
closed-loop linkage, motion timing, Pi stepper worker, live commanded-step
animation and v14 pen-servo burst mode.

## Folder layout

```
Whiteboard_Arm_Clean/
  main.py             <- edit ALL robot constants here; Run this in VS Code
  requirements.txt    <- Windows dependencies
  README.md
  core/               <- internal code; normally don't edit
    desktop.py        <- Tkinter GUI, SSH, animation and G-code export
    geometry.py       <- forward/inverse closed-loop kinematics
    vectorize.py      <- raster processing, centerline/outline tracing
    continuous_trace.py
    stroke_continuity.py
    bspline_path.py    <- fitted B-splines
    motion_plan.py    <- lookahead acceleration/curvature limits
    pi_worker.py      <- uploaded to Pi automatically for each hardware job
  tests/
    test_sanity.py    <- CPU-only verification (does not move motors)
```

## First-time setup on Windows (VS Code PowerShell)

Extract this folder and open it with **File → Open Folder** in VS Code.
In the PowerShell terminal from this folder:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe main.py
```

Later: only run ` .\.venv\Scripts\python.exe main.py `.
In VS Code, select the `.venv` interpreter and press **Run Python File**
while editing `main.py`.

## Raspberry Pi preparation (one-time)

SSH needs to be enabled; on the Pi:

```bash
sudo apt update
sudo apt install -y python3-lgpio openssh-server
sudo systemctl enable --now ssh
```

The laptop runs the program; the Pi receives `core/pi_worker.py` and
`core/motion_plan.py` automatically over SSH for each job. No web server.
Enter the SSH password into the desktop window (the password is not saved).

## Everyday workflow

1. In `main.py` edit link lengths, pulley reductions, rod lengths, the image
   cleanup settings, acceleration and pen-up/down servo pulses. Restart the
   application for edits to take effect. GUI settings can be modified for a
   single session, but edits in the GUI do **not** rewrite `main.py`.
2. Select an image and click **Preview only**.
3. Verify a consistent physical home position and the CAD linkage geometry.
   Check motor direction, current limits, microstepping DIP switches, servo
   clearances, and freely moving arm **without a marker** before applying load.
4. Choose **RUN ON RASPBERRY PI**. The animation uses Pi-reported **commanded
   steps**; it cannot detect stalls or missed steps without encoders.
5. Press **STOP MOTORS** to request an SSH stop; software and Wi-Fi cannot
   guarantee immediate physical emergency stopping. Provide a hardwired stop
   for the final system.

## Important mechanical assumptions

- The board is 48 × 60 inches with the shoulder at its top center.
- The closed-loop linkage model uses distinct primary arm, secondary rod,
  crank and forearm attachment points. Input radius, elbow lever radius,
  phase and attachment locations MUST be verified in CAD.
- `BAR_SPACING_IN` is nominal documentation; the true forearm attachment
  point is set by `ELBOW_LEVER_RADIUS_IN` and `ELBOW_PIN_PHASE_DEG`.
- The physical pen lift must run from a **separate regulated supply** rated
  for the servo, sharing ground with the Pi. Never apply the 24V motor
  supply directly to a servo.
- `PEN_SERVO_HOLD_PWM = False` reduces continuous PWM jitter but removes
  active servo holding force once positioning pulses end.
- There are no physical encoders, homing switches or collision protection.

## Dependencies

Windows: Pillow, NumPy, OpenCV, Paramiko, Python Tkinter (standard on Windows).
Pi: system `python3-lgpio`; a basic Raspberry Pi OS install.
