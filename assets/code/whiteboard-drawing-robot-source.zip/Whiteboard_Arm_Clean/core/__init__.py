"""Internal components of the Whiteboard Arm desktop controller."""
