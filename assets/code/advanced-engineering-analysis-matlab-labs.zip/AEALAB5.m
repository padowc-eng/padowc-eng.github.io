%Advanced Engineering Analysis
%Lab 5
clear
clc
%Problem 2
%Part a, Compute the first 4 eigen-functions
syms x

eq = tan(sqrt((x+3) / 4)) - sqrt(x+3) == 0;

guess = linspace(.1, 100000, 1500);
eigenvalues = zeros(1, length(guess));

for i = 1:length(guess)
    eigenvalues(i) = double(vpasolve(eq, x, guess(i)));
end

uniqueeig = unique(round(eigenvalues(eigenvalues>0), 8));
firstfour = uniqueeig(1:4);

% Display results
disp('The first 4 eigenvalues are:')
disp(firstfour');

%Part b, Plot the first four eigenfunctions
%%

for i = 1:4
    omega = @(x) log(x)* sqrt((firstfour(i)+3)/4); %Used for simplification
    eigenfunction = @(x) (x.^-.5) .*(cos(omega(x)) -(1/(sqrt(firstfour(i)+3))) .*sin(omega(x)));
    fplot(eigenfunction, [1, exp(1)], 'DisplayName', sprintf('Mode %d', i));
    hold on
end
xlabel('x'); 
ylabel('yn/Dn');
title('Normalized first 4 Eigenfunctions')   
legend 'Mode 1' 'Mode 2' 'Mode 4' 'Mode 3' 
grid on
%Part c Show orthogonality relation between the first two eigenfunctions
%%
syms x
    omega1 = log(x) * sqrt((firstfour(1)+3)/ 4);  
    omega2 = log(x) * sqrt((firstfour(2)+3)/ 4);
    eigenfunction1 = (x.^-.5) .*((cos(omega1) -(1/(sqrt(firstfour(1) +3))) .*sin(omega1)));
    eigenfunction2 = (x.^-.5) .*((cos(omega2) -(1/(sqrt(firstfour(2) +3))) .*sin(omega2)));

multipliedeigenvectors = .25* eigenfunction1 * eigenfunction2;
orthogalcheck = double(int(multipliedeigenvectors, x, 1, exp(1)))

%Part d compute coefficients for f(x)
%%
sumcount = 50;
Dnc = zeros(1,sumcount);
eigenfunctionsum = 0;
syms x 
for i = 1:sumcount
    omega = @(x) log(x)* sqrt((uniqueeig(i)+3)/4); %Used for simplification
    top = @(x) sin(pi*x) .*(x.^.5) .*(cos(omega(x)) -(1/(sqrt(uniqueeig(i)+3))) .*sin(omega(x))) ;
    bottom = @(x)  (x.^-1) .*(cos(omega(x)) -(1/(sqrt(uniqueeig(i)+3))) .*sin(omega(x))).^2 ;
    Dn = integral(top, 1, exp(1))  /   integral(bottom, 1, exp(1));
    Dnc(i) = Dn;
    eigenfunction = Dn* (x.^-.5) .*((cos(omega(x)) -(1/(sqrt(uniqueeig(i)+3))) .*sin(omega(x))));
    eigenfunctionsum = eigenfunctionsum + eigenfunction;

if rem(i, 5) ==0
    figure
    fplot(x*sin(pi*x),[1,exp(1)])
    hold on
    fplot(eigenfunctionsum,[1,exp(1)],'--')
    xlabel('x'); ylabel('f(x)');
    legend('x*sin(x)','Eigenfunction Sum')
    title(sprintf('Eigenfunction Series Approximation with %d Terms',i))    
    grid on

end

end
disp('The Coefficients are:')
disp(Dnc');

%Problem 3
%Part e 
%%
syms x
eq = besselj(1, x) == 0;
guesses = linspace(.1, 20, 100);
eigenvalues_bessel = zeros(1, length(guesses));

for i = 1:length(guesses)
    eigenvalues_bessel(i) = double(vpasolve(eq, x, guesses(i)));
end

uniqueeig_bessel = unique(round(eigenvalues_bessel(eigenvalues_bessel>0), 8));
firstfive_bessel = uniqueeig_bessel(2:6);
eigenfunctionsum = 0;
for i = 1:5

    top = @(x) x.*((x.*(1-x)).*exp(-10*x.^2)) .*besselj(1,(firstfive_bessel(i).*x));
    bottom = @(x)  x.*(besselj(1,(firstfive_bessel(i).*x))).^2 ;
    Cn = integral(top, 0, 1)  /   integral(bottom, 0, 1);

    eigenfunction = Cn* besselj(1,(firstfive_bessel(i)*x));
    eigenfunctionsum = eigenfunctionsum + eigenfunction;
end
%%
figure
fplot(((x*(1-x))*exp(-10*x^2)),[0, 1],'--') ;
hold on
fplot(eigenfunctionsum,[0,1])
xlabel('x'); ylabel('f(x)');
legend('Exact Solution','Eigenfunction Sum')
title('Eigenfunction Series Approximation of (x*(1-x))*exp(-10*x^2) with 5 Terms')   
grid on
