"""Cubic C2 B-spline interpolation of image strokes in whiteboard coordinates (inches).

- Interpolates the sampled centerline/contour points via a banded (strictly
  diagonally dominant) cubic cardinal B-spline control-point solve.
- Closed contours are interpolated periodically, including the seam.
- Samples every <= SAMPLE_IN (nominal) and checks each chord against
  the marker-clearance workspace. Invalid/overshooting strokes fall back to
  the original polyline rather than silently clipping unsafe tool paths.
- Pen-up travel moves are intentionally NOT splined.
- This is GEOMETRIC path interpolation; velocity remains under motion_plan.py.
"""
from __future__ import annotations
import math
import numpy as np
import main as C
from bisect import bisect_left

KNOT_IN = C.SPLINE_KNOT_SPACING_IN            # spacing of points the B-spline passes through
SAMPLE_IN = C.SPLINE_SAMPLE_SPACING_IN          # max nominal distance between generated waypoints
MAX_EXTRA_DEVIATION_IN = C.SPLINE_MAX_DEVIATION_IN  # max shape change versus original polyline
MAX_OUTPUT_POINTS = 50000


def _dist(a, b):
    return math.hypot(a[0]-b[0], a[1]-b[1])


def _resample(points, spacing, closed):
    """Even arc-length sampling of the original polygon (not the new spline)."""
    pts = [(float(x), float(y)) for x, y in points]
    filtered = [pts[0]]
    for p in pts[1:]:
        if _dist(p, filtered[-1]) > 1.e-8:
            filtered.append(p)
    if closed and len(filtered)>2 and _dist(filtered[-1], filtered[0])<0.02:
        filtered.pop()
    if len(filtered)<2:
        return filtered
    chain = filtered + ([filtered[0]] if closed else [])
    dists = [0.0]
    for a, b in zip(chain, chain[1:]):
        dists.append(dists[-1]+_dist(a,b))
    total = dists[-1]
    if total<1e-8:
        return [chain[0]]
    intervals = max(4 if closed else 1, math.ceil(total / spacing))
    # Protect against huge raster polylines; the outer caller has a point cap.
    intervals = min(intervals, 12000)
    query = (i * total/intervals for i in range(intervals if closed else intervals+1))
    sampled = []
    for target in query:
        j = max(0, min(len(chain)-2, bisect_left(dists, target)-1))
        f = (target-dists[j]) / max(1e-12,dists[j+1]-dists[j])
        sampled.append((chain[j][0]+f*(chain[j+1][0]-chain[j][0]),
                        chain[j][1]+f*(chain[j+1][1]-chain[j][1])))
    if not closed:
        sampled[0],sampled[-1] = chain[0],chain[-1]
    return sampled


def _regularized_best_fit(raw, closed, marker_diameter):
    """Fitted, not pixel-interpolating, B-spline knots.

    Minimize ||q-raw||^2 + lambda ||D2 q||^2 using gradient descent.
    True acute corners are anchors so logo tips are not rounded away. The
    maximum correction is limited by marker width and a small absolute cap.
    """
    p = np.asarray(raw, dtype=np.float64)
    n = len(p)
    if n < 5:
        return raw
    anchors = np.zeros(n, dtype=bool)
    if not closed:
        anchors[0] = anchors[-1] = True
    for i in range(0 if closed else 2, n if closed else n-2):
        prev, nxt = p[(i-2)%n], p[(i+2)%n]
        va = p[i] - prev
        vb = nxt - p[i]
        denom = np.linalg.norm(va)*np.linalg.norm(vb)
        if denom > 1e-12:
            angle = math.acos(float(np.clip(np.dot(va,vb)/denom,-1,1)))
            if angle > 0.9:  # retain major >~52-degree intentional corners
                anchors[i] = True
    result = p.copy()
    lam = 0.6
    step = 0.075  # stable for biharmonic smoothing at lambda=0.6
    for _ in range(70):
        if closed:
            d2 = np.roll(result,1,axis=0)-2*result+np.roll(result,-1,axis=0)
            d4 = np.roll(d2,1,axis=0)-2*d2+np.roll(d2,-1,axis=0)
        else:
            d2 = result[:-2]-2*result[1:-1]+result[2:]
            d4 = np.zeros_like(result)
            d4[:-2] += d2
            d4[1:-1] -= 2*d2
            d4[2:] += d2
        result -= step * ((result-p) + lam*d4)
        result[anchors] = p[anchors]
    max_dist = min(0.095, max(0.025, marker_diameter * 0.38))
    d = result-p
    norm = np.linalg.norm(d, axis=1)
    scale = np.minimum(1.0, max_dist / np.maximum(norm,1e-12))
    result = p + d*scale[:,None]
    result[anchors] = p[anchors]
    return [tuple(point) for point in result]


def _control_points(q, closed):
    """Solve Q_i = (P_{i-1} + 4 P_i + P_{i+1})/6 with Jacobi iteration.

    The diagonal dominance factor (off-diagonal sum / diagonal = 1/2)
    guarantees geometric convergence. Open curves use natural end conditions;
    periodic curves wrap their control points, producing a C2 closed seam.
    """
    p = list(q)
    n = len(q)
    for _ in range(54):
        old = p
        if closed:
            p = [(1.5*q[i][0] - .25*(old[(i-1)%n][0]+old[(i+1)%n][0]),
                  1.5*q[i][1] - .25*(old[(i-1)%n][1]+old[(i+1)%n][1])) for i in range(n)]
        else:
            p = [q[0]] + [(1.5*q[i][0]-.25*(old[i-1][0]+old[i+1][0]),
                           1.5*q[i][1]-.25*(old[i-1][1]+old[i+1][1]))
                          for i in range(1,n-1)] + [q[-1]]
    return p


def _spline_point(control, i, t, closed):
    n = len(control)
    def c(j):
        if closed:
            return control[j % n]
        if j < 0:
            return (2*control[0][0]-control[1][0], 2*control[0][1]-control[1][1])
        if j >= n:
            return (2*control[-1][0]-control[-2][0], 2*control[-1][1]-control[-2][1])
        return control[j]
    b = ((1-t)**3/6,
         (3*t**3-6*t**2+4)/6,
         (-3*t**3+3*t*t+3*t+1)/6,
         t**3/6)
    pp = [c(i-1),c(i),c(i+1),c(i+2)]
    return tuple(sum(b[j]*pp[j][k] for j in range(4)) for k in (0,1))


def _distance_to_segment(p,a,b):
    vx,vy=b[0]-a[0],b[1]-a[1]
    lensq=vx*vx+vy*vy
    if lensq<1.e-14:return _dist(p,a)
    t=max(0.,min(1.,((p[0]-a[0])*vx+(p[1]-a[1])*vy)/lensq))
    return _dist(p,(a[0]+t*vx,a[1]+t*vy))


def cubic_bspline(path, geometry, knot_spacing=KNOT_IN, sample_spacing=SAMPLE_IN,
                  max_extra_deviation=MAX_EXTRA_DEVIATION_IN):
    """Return (sampled_path, interpolated_ok). For unsafe curves, return raw path.

    Cubic uniform B-spline interpolation with chord-length equalized knots.
    Through-points are original-polyline arc-length samples, not all raw pixels.
    """
    raw = [tuple(map(float, pt)) for pt in path]
    if len(raw)<3:
        return raw, False
    closed = len(raw)>3 and _dist(raw[0],raw[-1])<.02
    q = _resample(raw, knot_spacing, closed)
    if len(q)<(4 if closed else 3):
        return raw,False
    fitted = _regularized_best_fit(q, closed, geometry.marker_diameter)
    control = _control_points(fitted, closed)
    segments = len(q) if closed else len(q)-1
    result = [q[0]]
    # Extend the curve evaluation and chord checks to the workspace boundary.
    pad = geometry.marker_diameter/2
    max_deviation = min(max_extra_deviation, max(0.015, pad))
    for i in range(segments):
        # The neighboring B-spline control points can overshoot; sample densely
        # enough that straight motor chords remain well inside clearance limits.
        estimated_length = max(knot_spacing, _dist(q[i],q[(i+1)%len(q)]))
        samples = max(3, math.ceil(estimated_length/sample_spacing))
        for j in range(1,samples+1):
            t=j/samples
            p=_spline_point(control,i,t,closed)
            if not geometry.valid(*p, pad):
                return raw,False
            # Guard against pronounced oscillation outside the original trace.
            nearby=[]
            for k in range(i-2,i+3):
                if closed:
                    a,b=q[k%len(q)],q[(k+1)%len(q)]
                elif 0<=k<len(q)-1:
                    a,b=q[k],q[k+1]
                else:
                    continue
                nearby.append(_distance_to_segment(p,a,b))
            if nearby and min(nearby)>max_deviation:
                return raw,False
            last=result[-1]
            for m in range(1,math.ceil(_dist(last,p)/sample_spacing)+1):
                f=m/max(1,math.ceil(_dist(last,p)/sample_spacing))
                intermediate=(last[0]+f*(p[0]-last[0]),last[1]+f*(p[1]-last[1]))
                if not geometry.valid(*intermediate,pad):
                    return raw,False
            if _dist(last,p)>1e-8:
                result.append(p)
    if not closed:
        result[-1]=raw[-1]
    else:
        result[-1]=raw[0]
    # Preserve the original closed-stroke topology and avoid exact duplicate
    # consecutive waypoints that would create zero-step motion segments.
    cleaned=[result[0]]
    for p in result[1:]:
        if _dist(p, cleaned[-1]) > 0.012:
            cleaned.append(p)
    if closed and _dist(cleaned[0],cleaned[-1]) > 0.001:
        cleaned.append(cleaned[0])
    return cleaned,True


def interpolate_strokes(paths, geometry, max_total=MAX_OUTPUT_POINTS):
    """Return (smoothed_strokes, count_interpolated, count_fallback).

    Preserve stroke boundaries and endpoints. Never spline travel pen-up hops.
    """
    smoothed=[]
    n_ok=n_fallback=0
    total=0
    for path in paths:
        p, ok = cubic_bspline(path,geometry)
        # Avoid accidental expansion into a job beyond hardware memory budget.
        if total+len(p)>max_total:
            raise ValueError('B-spline paths exceed safe point budget; use a simpler image or outline mode')
        smoothed.append(p)
        total+=len(p)
        n_ok+=int(ok)
        n_fallback+=int(not ok)
    return smoothed,n_ok,n_fallback
