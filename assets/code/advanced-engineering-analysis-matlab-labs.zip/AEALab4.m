% % Advanced Engineering Analysis 
% % William Pado
% % Lab 4
% 
%Problem 2
%Part a; Plot the Bessel functions

syms  x  %nu is order, x is x

for nu = 0:2
J1 = besselj(nu,x) ;%Bessel function of 1st kind

J2 = bessely(nu,x) ;%Bessel function of 2nd kind

J3 = besseli(nu,x);   %Modified Bessel function of 1st kind

J4 = besselk(nu,x);   %Modifed Bessel function of 2nd kind

figure
xlim([0, 10])
ylim([-2, 5])
fplot(J1, [0, 10], LineWidth=2, Color='blue', LineStyle='--')
hold on
fplot(J2, [0, 10], LineWidth=2, Color='red', LineStyle=':')
fplot(J3, [0, 5], LineWidth=2, Color='green')
fplot(J4, [0, 5], LineWidth=2, Color='black')
xlim([0, 10])
ylim([-5, 5])

hold off
grid on
xlabel ('Z')
ylabel ('Output of bessel functions')
title("Bessel functions of order: n =  " + nu)
legend 'Bessel of 1st kind' 'Bessel of 2nd kind ' ' Modified 1st kind' 'Modified 2nd kind'

end

% Part b, Plot the partial sums with 5, 10, and 15 terms together
target_error = 0.01;
syms x
styles = {'-', '--', ':'};
terms= [5, 10, 15];
figure
hold on
for i = 1:3
sum = 0;
for l = 0:(terms(i) -1)

    sum = sum + ((-1)^l)./ ((factorial(l))^2 )  * ((x/2)^(2*l));
end
sum = @(x) sum;
fplot(sum(x), [.001,10], styles{i},LineWidth=2)
ylim([-10, 10])

error = abs(sum - besselj(0, x)) == target_error;
x_err = vpasolve(error, x, [0, 15]);

% Print the exact root to the command window
fprintf('%d Terms: Error is %g at x = %.6f\n', terms(i), target_error, double(x_err));
end
fplot(@(x) besselj(0,x),[0,10])
grid on
xlabel('x')
ylabel('Partial Sum')
title('Bessel Function J_0 Partial Sums')
legend('5 Terms','10 Terms','15 Terms', 'Exact')

%Part C
roots = zeros(2,5);

for n = 0:1
    f = @(x) besselj(n,x);
    rootcount = 0;
    i = 1.001;

    while rootcount < 5
        if f(i-1)*f(i) < 0
            rootcount = rootcount + 1;
            roots(n+1,rootcount) = fzero(f,[i-1,i]);
        end
        i = i+1;
    end
end

root0 = roots(1,:)
root1 = roots(2,:)
J0atJ1 = besselj(0,root1)

figure
fplot(@(x) besselj(0,x),[0,17])
hold on
xline(root1,'--k','HandleVisibility','off')
plot(root1, J0atJ1,'ro','MarkerFaceColor','blue')
grid on
xlabel('x')
ylabel('J_0(x)')
title('Bessel Function J_0 and Zeros of J_1')
legend('J_0(x)','J_0 at J_1 Zeros')
hold off


% %Problem 3

% Part b Calculations 
syms A B
digits(8)
qlaser = 1.2;
ht = 15;
rd = .02;
r1 = .001;
td = .002;
k = 1.1;
m = sqrt(2*ht / (k*td));

eqn1 = -qlaser / (2*pi*r1*td*k) == m*(A* besseli(1,  r1*m) - B * besselk(1, r1*m));
eqn2 = -(ht/k)*(A* besseli(0, rd*m) + B* besselk(0, rd*m)) == m* (A*besseli(1, (rd*m)) - B*besselk(1, rd*m)  );

sol = solve([eqn1, eqn2], [A, B]);
A = vpa(sol.A,5)
B = vpa(sol.B,5)

%Part c
theta = @(r) A* besseli(0, m*r) + B* besselk(0, m*r);
fplot(theta,[r1,rd])
hold on
title('\theta (r)')
xlabel('r (m)')
ylabel('\theta')
TempLaser = theta(r1)
TempRim = theta(rd)

% Part D, rim is 

syms C D
eqn1 = -qlaser / (2*pi*r1*td*k) == m*(C* besseli(1,  r1*m) - D * besselk(1, r1*m));
eqn2 = 0 ==  C*besseli(0,rd*m)+D*besselk(0,rd*m);
sol2 = solve([eqn1, eqn2], [C, D]);
C = vpa(sol2.C,5)
D = vpa(sol2.D,5)

theta1 = @(r) C* besseli(0, m*r) + D* besselk(0, m*r);
fplot(theta1,[r1,rd])
TempLaser = theta1(r1)
TempRim = theta1(rd)
legend 'rd\neq  T \infty' 'rd = T \infty'


%Part D Peak Temperature Comparison
PeakNormal = theta(r1);
PeakFixedRim = theta1(r1);
PeakDifference = PeakNormal - PeakFixedRim