"""WHITEBOARD ARM — MASTER FILE

Edit the settings below, save, and run this file in VS Code.
Only this file needs editing to configure the robot; core/ is implementation.

Lengths: inches. Angles: degrees where named *_DEG. Speed/accel/jerk
are motor microsteps/s, microsteps/s², microsteps/s³ respectively.

HARDWARE WARNING: the linkage model is calibrated only when the listed pivot
and pulley dimensions match your CAD/physical arm. Motion uses commanded
steps (no encoders). Home manually and remove the marker for first tests.
"""

# ——— Pi connection ———
SSH_HOST = "4gb.local"
SSH_USER = "padowc"
# Password is entered in the window; it is deliberately NOT stored here.

# ——— Whiteboard, arm and pen ———
BOARD_W_IN = 48.0
BOARD_H_IN = 60.0
LINK_1_IN = 20.0                # Shoulder axis O to elbow J
LINK_2_IN = 20.0                # Elbow J to marker tip T
BAR_SPACING_IN = 3.0            # Nominal spacing for parallel mechanism
MARKER_DIAMETER_IN = 0.25
BOARD_MARGIN_IN = 1.5
HOME_Y_IN = 26.0                 # Home X = half board width
ELBOW_BRANCH = 1                # +1 or -1 IK branch

# ——— Pulley and closed-loop linkage ———
MOTOR_1_REDUCTION = 4.0         # Motor turns / pulley output turn
MOTOR_2_REDUCTION = 4.0
INPUT_EFFECTIVE_RADIUS_IN = 3.0 # Second pulley crank O2→A, measure in CAD
ELBOW_LEVER_RADIUS_IN = 3.0     # Elbow J→secondary rod pin B, measure
SECONDARY_ROD_LENGTH_IN = 20.0  # Secondary link A→B, measure
CRANK_CENTER_DX_IN = 0.0        # Second output axis center relative to O
CRANK_CENTER_DY_IN = 0.0
ELBOW_PIN_PHASE_DEG = 0.0       # Forearm attachment angle relative J→T
ELBOW_TRANSFER = "closed_loop"
SWAP_MOTOR_CHANNELS = False
INVERT_MOTOR_1 = False
INVERT_MOTOR_2 = False
STEPS_PER_MOTOR_REV = 200
MICROSTEPS = 8                  # MUST match the HAT DIP switches

# ——— Image cleanup and vectorization ———
IMAGE_MODE = "centerline"       # "centerline" or "outline"
IMAGE_CONTRAST = 1.5
IMAGE_THRESHOLD = 0             # 0: automatic threshold
IMAGE_NOISE = 1
IMAGE_SIMPLIFY_PX = 1.0
IMAGE_MIN_AREA_PX = 12
IMAGE_GAP_REPAIR_PX = 6
RECOGNIZE_SIMPLE_LOOPS = True
STROKE_JOIN_GAP_IN = 0.15
PEN_LIFT_IGNORE_GAP_IN = 0.06
SPLINE_KNOT_SPACING_IN = 0.26
SPLINE_SAMPLE_SPACING_IN = 0.075
SPLINE_MAX_DEVIATION_IN = 0.125

# ——— Trajectory speed, acceleration and jerk ———
MAX_MOTOR_RATE = 650            # Initial GUI speed / microsteps per second
MOTOR_ACCEL = 900.0
MOTOR_JERK = 3000.0
MAX_CENTRIPETAL_IN_S2 = 3.0
DETAIL_RADIUS_IN = 0.9
DETAIL_SPEED_FACTOR = 0.55
TRAVEL_SPEED_FACTOR = 1.0
JUNCTION_DEVIATION_STEPS = 4.0
STEP_CHUNK = 12                 # Lower = faster response to software STOP

# ——— Marker lift micro servo (separate regulated 5V supply) ———
PEN_SERVO_ENABLED = True
PEN_SERVO_GPIO = 23             # BCM GPIO, not physical pin number
PEN_UP_PULSE_US = 1500
PEN_DOWN_PULSE_US = 2000        # Calibrate before attaching mechanism
PEN_SERVO_SETTLE_S = 0.45
PEN_SERVO_HOLD_PWM = False      # False reduces idle jitter but loses holding torque
PEN_SERVO_PULSE_CYCLES = 30    # 30 cycles at 50 Hz ~0.6 seconds


if __name__ == "__main__":
    from core.desktop import launch
    launch()
