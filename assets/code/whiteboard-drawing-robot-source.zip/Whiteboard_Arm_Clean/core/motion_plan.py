"""Curvature-sensitive look-ahead planner for a differential two-motor drawing arm.

Speed is expressed in maximum motor-axis microsteps/s.  The planner also
limits Cartesian speed using curvature to bound centripetal acceleration,
slows down on small detail, and performs forward/backward acceleration look-
ahead.  Chunk acceleration is softly ramped to reduce abrupt changes.  This
is NOT a formally time-optimal or strictly jerk-bounded S-curve trajectory.
Raspberry Pi/Linux timing and step quantization impose residual motor jerk.
"""
from __future__ import annotations
import math

MIN_PULSE_S = .000025


def _curvature(p0, p1, p2):
    ax,ay = p1[0]-p0[0],p1[1]-p0[1]
    bx,by = p2[0]-p1[0],p2[1]-p1[1]
    ab=math.hypot(ax,ay)
    bc=math.hypot(bx,by)
    ac=math.hypot(p2[0]-p0[0],p2[1]-p0[1])
    if min(ab,bc,ac)<1e-8:
        return 0.0
    return 2.0*abs(ax*by-ay*bx)/(ab*bc*ac)


class RatePlanner:
    def __init__(self, peak=650, accel=900, jerk=6000, max_centripetal=3.0,
                 detail_radius=.9, detail_factor=.55, travel_factor=1.0,
                 junction_dev=4.0, chunk=12):
        self.peak=max(100.0,min(10000.0,float(peak)))
        self.accel=max(50.0,min(20000.0,float(accel)))
        self.jerk=max(100.0,min(100000.0,float(jerk)))
        self.centripetal=max(.05,float(max_centripetal))
        self.detail_radius=max(.03,float(detail_radius))
        self.detail_factor=max(.05,min(1.0,float(detail_factor)))
        self.travel_factor=max(.1,min(1.0,float(travel_factor)))
        self.junction_dev=max(.2,float(junction_dev))
        self.chunk=max(1,min(40,int(chunk)))
        self.entry=[]
        self.index=0
        self._ready=False
        self.last_accel=0.0
        self.local_speed_caps=[]
        self.curvatures=[]

    def prepare(self,moves):
        n=len(moves)
        dist=[]; vec=[]; pen=[]; coords=[]; motor_deltas=[]
        before=(0,0)
        for m in moves:
            target=int(m[0]),int(m[1])
            dx,dy=target[0]-before[0],target[1]-before[1]
            d=max(abs(dx),abs(dy))
            h=math.hypot(dx,dy)
            dist.append(d)
            vec.append((dx/h,dy/h) if h else None)
            motor_deltas.append((dx,dy))
            pen.append(bool(m[2]))
            coords.append((float(m[3]),float(m[4])))
            before=target

        # For each waypoint, constrain MOTOR rate with Cartesian curvature.
        # Local conversion k = max motor-axis steps / inch along that path.
        speed_limit=[self.peak]*(n+1)
        curvature=[0.0]*n
        for i in range(1,n-1):
            if not (pen[i-1] and pen[i] and pen[i+1]):
                continue
            kappa=_curvature(coords[i-1],coords[i],coords[i+1])
            curvature[i]=kappa
            if kappa<1e-7:
                continue
            cart_speed=math.sqrt(self.centripetal/kappa)
            steps=max(abs(motor_deltas[i][0]),abs(motor_deltas[i][1]),
                      abs(motor_deltas[i+1][0]),abs(motor_deltas[i+1][1]))
            path_in=max(.000001,math.dist(coords[i-1],coords[i]),
                        math.dist(coords[i],coords[i+1]))
            step_per_in=max(1.0,steps/path_in)
            cap=cart_speed*step_per_in
            if kappa*self.detail_radius>=1.0:
                cap=min(cap,self.detail_factor*self.peak)
            speed_limit[i+1]=min(speed_limit[i+1],max(4.0,cap))
        for i in range(n):
            if not pen[i]:
                speed_limit[i]=min(speed_limit[i],self.peak*self.travel_factor)
                speed_limit[i+1]=min(speed_limit[i+1],self.peak*self.travel_factor)
        speed_limit[0]=0.0
        speed_limit[n]=0.0
        for i in range(1,n):
            if pen[i-1]!=pen[i]:
                speed_limit[i]=0.0  # separate pen-up and drawing strokes
            a=vec[i-1];b=vec[i]
            if a is None or b is None:
                continue
            cosine=max(-1.0,min(1.0,a[0]*b[0]+a[1]*b[1]))
            turn=1.0-cosine
            if turn>1e-7:
                speed_limit[i]=min(speed_limit[i],
                     math.sqrt(2*self.accel*self.junction_dev/turn))
            # A moving motor reversing sign must pass through zero speed.
            if any(motor_deltas[i-1][j]*motor_deltas[i][j]<0 for j in (0,1)):
                speed_limit[i]=min(speed_limit[i],self.peak*.12)

        speeds=speed_limit[:]
        for i in range(n):
            speeds[i+1]=min(speeds[i+1],math.sqrt(speeds[i]**2+2*self.accel*dist[i]))
        for i in range(n-1,-1,-1):
            speeds[i]=min(speeds[i],math.sqrt(speeds[i+1]**2+2*self.accel*dist[i]))
        self.entry=speeds
        self.index=0
        self.last_accel=0.0
        self.local_speed_caps=speed_limit
        self.curvatures=curvature
        self._ready=True

    def _chunk_time(self,d,v0,v1):
        if d<=0:return 0.0
        a=self.accel
        v0=max(0.,min(self.peak,v0));v1=max(0.,min(self.peak,v1))
        vp=math.sqrt(max(0.,a*d+(v0*v0+v1*v1)/2))
        if vp<=self.peak:
            return max(2*MIN_PULSE_S*d,(2*vp-v0-v1)/a)
        da=max(0.,(self.peak**2-v0**2)/(2*a))
        dd=max(0.,(self.peak**2-v1**2)/(2*a))
        return max(2*MIN_PULSE_S*d,(self.peak-v0)/a+(self.peak-v1)/a+
                   max(0.,d-da-dd)/self.peak)

    def segment(self,before,after,pen):
        dx=int(after[0])-int(before[0]);dy=int(after[1])-int(before[1])
        delta=(dx,dy)
        count=max(abs(dx),abs(dy))
        if self._ready:
            if self.index+1>=len(self.entry):
                raise RuntimeError('Planner index exceeded job')
            start_speed,end_speed=self.entry[self.index:self.index+2]
            self.index+=1
        else:
            start_speed=end_speed=0.0
        speed=start_speed
        for begin in range(0,count,self.chunk):
            end=min(count,begin+self.chunk)
            d=end-begin
            remain=count-end
            brake=math.sqrt(end_speed**2+2*self.accel*remain)
            ideal=min(self.peak,math.sqrt(speed**2+2*self.accel*d),brake)
            # Soft acceleration/jerk shaping.  Safety look-ahead wins if the
            # requested deceleration is sharper than the jerk preference.
            dt_est=d/max(40.,.5*(speed+ideal))
            a_desired=(ideal**2-speed**2)/(2*d)
            da_max=self.jerk*dt_est
            a_ramped=max(self.last_accel-da_max,min(self.last_accel+da_max,a_desired))
            a_ramped=max(-self.accel,min(self.accel,a_ramped))
            next_speed=math.sqrt(max(0.,speed**2+2*a_ramped*d))
            if ideal<speed:
                next_speed=min(next_speed,ideal)
            next_speed=min(next_speed,self.peak,brake)
            if end==count:
                next_speed=min(next_speed,end_speed)
            duration=self._chunk_time(d,speed,next_speed)
            self.last_accel=(next_speed**2-speed**2)/(2*d)
            counts=tuple((end*abs(delta[j]))//count-(begin*abs(delta[j]))//count
                         for j in (0,1))
            speed=next_speed
            yield end,count,counts,max(duration,MIN_PULSE_S*2*d)


def estimate_seconds(moves,peak=650,**kwargs):
    plan=RatePlanner(peak,**kwargs)
    plan.prepare(moves)
    pos=(0,0); total=0.
    for row in moves:
        target=int(row[0]),int(row[1])
        for _,_,_,duration in plan.segment(pos,target,bool(row[2])):
            total+=duration+.0008
        pos=target
    return total


def format_eta(seconds):
    seconds=max(0,int(math.ceil(seconds)))
    h,r=divmod(seconds,3600)
    m,s=divmod(r,60)
    return f'{h}:{m:02d}:{s:02d}' if h else f'{m}:{s:02d}'


def estimate_pen_seconds(moves, settle_s=0.45, enabled=True):
    """Servo starts retracted and only moves when pen state changes."""
    if not enabled:
        return 0.0
    changes = 0
    previous = False
    for row in moves:
        state = bool(row[2])
        if state != previous:
            changes += 1
            previous = state
    # Initial retraction at job start, even if first waypoint is travel.
    return (1 + changes) * max(0.0, float(settle_s))
