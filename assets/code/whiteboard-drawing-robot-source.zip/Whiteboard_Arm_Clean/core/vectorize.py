"""Raster -> filtered binary -> contour or centerline vector polylines."""
import cv2
import numpy as np
from PIL import Image,ImageOps
import io
import math

MAX_IMAGE_SIDE=850


def preprocess(image_bytes, options):
    im=Image.open(io.BytesIO(image_bytes))
    im=ImageOps.exif_transpose(im)
    # If transparent, use white background
    if im.mode in ('RGBA','LA') or 'transparency' in im.info:
        rgba=im.convert('RGBA')
        bg=Image.new('RGBA', rgba.size, 'white')
        bg.alpha_composite(rgba)
        im=bg.convert('RGB')
    im=im.convert('L')
    im.thumbnail((MAX_IMAGE_SIDE, MAX_IMAGE_SIDE),Image.Resampling.LANCZOS)
    gray=np.asarray(im).copy()
    contrast=float(options.get('contrast',1.6))
    if not 0.5<=contrast<=5:raise ValueError('Contrast outside allowed range')
    # CLAHE reduces large-area background variations in photographs.
    enhanced=cv2.createCLAHE(clipLimit=contrast*1.4,tileGridSize=(8,8)).apply(gray)
    smooth=cv2.GaussianBlur(enhanced,(3,3),0)
    offset=int(options.get('threshold',0))
    if not -100<=offset<=100:raise ValueError('Threshold offset must be -100 to 100')
    threshold,_=cv2.threshold(smooth,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
    binary=np.uint8(smooth<np.clip(threshold+offset,0,255))*255
    if bool(options.get('invert',False)):binary=cv2.bitwise_not(binary)
    noise=int(options.get('noise',1))
    if not 0<=noise<=5:raise ValueError('Noise parameter must be 0-5')
    if noise:
        # A 3x3 morphological OPEN was destroying one-pixel logo outlines and
        # creating false pen-up gaps. Keep thin lines; remove only tiny isolated
        # connected components (not short segments of a connected stroke).
        count, labels, stats, _ = cv2.connectedComponentsWithStats(binary, 8)
        min_pixels = max(3, 3 * noise * noise)
        keep = np.zeros(count, dtype=np.uint8)
        keep[1:] = (stats[1:, cv2.CC_STAT_AREA] >= min_pixels).astype(np.uint8)
        binary = keep[labels] * 255
    return binary


def skeletonize(binary):
    """One-pixel Zhang-Suen centerlines (avoids branching fat medial ridges).

    The previous erode/dilate morphological skeleton left large clusters of
    multi-degree vertices at antialiased diagonal lines, which led the route
    optimizer to invent zig-zags and repeat the same curve.
    """
    img=(binary > 0).astype(np.uint8)
    # Border padding ensures all neighbor slices are the same size.
    img=np.pad(img, ((1,1),(1,1)), mode='constant')
    for _ in range(150):
        before=np.count_nonzero(img)
        for phase in (0,1):
            p2=img[:-2,1:-1];p3=img[:-2,2:];p4=img[1:-1,2:]
            p5=img[2:,2:];p6=img[2:,1:-1];p7=img[2:,:-2]
            p8=img[1:-1,:-2];p9=img[:-2,:-2]
            mid=img[1:-1,1:-1]
            n=p2+p3+p4+p5+p6+p7+p8+p9
            s=((p2==0)&(p3==1)).astype(np.uint8)
            for a,b in ((p3,p4),(p4,p5),(p5,p6),(p6,p7),
                        (p7,p8),(p8,p9),(p9,p2)):
                s+=((a==0)&(b==1)).astype(np.uint8)
            if phase==0:
                constraint=((p2*p4*p6)==0)&((p4*p6*p8)==0)
            else:
                constraint=((p2*p4*p8)==0)&((p2*p6*p8)==0)
            remove=(mid==1)&(n>=2)&(n<=6)&(s==1)&constraint
            mid[remove]=0
        if np.count_nonzero(img)==before:
            break
    return img[1:-1,1:-1]*255

def ordered_skeleton_paths(binary,min_length=8):
    import collections
    sk=skeletonize(binary)
    ys,xs=np.nonzero(sk)
    points={(int(x),int(y)) for x,y in zip(xs,ys)}
    neighbors={p: [] for p in points}
    shifts=[(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]
    for x,y in points:
        p=(x,y)
        for dx,dy in shifts:
            n=(x+dx,y+dy)
            if n in points:
                # suppress diagonal if orthogonal connecting pixel exists
                if dx and dy and ((x+dx,y) in points or (x,y+dy) in points):continue
                neighbors[p].append(n)
    visited=set()
    def edge(a,b):return (a,b) if a<=b else (b,a)
    paths=[]
    def trace(start,nxt):
        path=[start]
        prev=start
        cur=nxt
        visited.add(edge(start,nxt))
        while True:
            path.append(cur)
            if cur==start or len(neighbors[cur])!=2:break
            other=[p for p in neighbors[cur] if p!=prev]
            if not other:break
            n=other[0]
            if edge(cur,n) in visited:break
            visited.add(edge(cur,n))
            prev,cur=cur,n
        if len(path)>=2:
            # shortest-path in image pixels rather than vertex count
            if sum(math.dist(a,b) for a,b in zip(path,path[1:]))>=min_length:
                paths.append(path)
    for p,nn in neighbors.items():
        if len(nn)!=2:
            for n in nn:
                if edge(p,n) not in visited:trace(p,n)
    for p,nn in neighbors.items():
        for n in nn:
            if edge(p,n) not in visited:trace(p,n)
    return paths


def extract_paths(binary, options, return_stats=False):
    from .continuous_trace import continuous_skeleton_paths, repair_skeleton_gaps
    from .stroke_continuity import recognize_circles, recognize_ellipses
    min_area=float(options.get('min_area',18))
    epsilon=float(options.get('simplify',1.0))
    mode=options.get('mode','outline')
    gap_px=int(options.get('gap_px', 6))
    if not 0<=epsilon<=5 or not 0<=min_area<=1000:
        raise ValueError('Invalid vectorization settings')
    if not 0<=gap_px<=12:
        raise ValueError('Gap repair must be from 0 to 12 pixels')
    stats={'gap_repairs':0, 'connected_strokes':0,'retraced_pixel_edges':0}
    detect_regular=bool(options.get('recognize_simple_loops', True))
    if mode=='centerline':
        sk=skeletonize(binary)
        repaired, original_joins=repair_skeleton_gaps(sk, gap_px=gap_px)
        if detect_regular:
            circles, leftover, circle_count=recognize_circles(repaired)
            ellipses, leftover, ellipse_count=recognize_ellipses(leftover)
        else:
            circles,ellipses= [],[]
            circle_count=ellipse_count=0
            leftover=repaired
        raw,stats=continuous_skeleton_paths(leftover,
            min_length=max(5.0,min_area**.5),gap_px=0)
        stats['gap_repairs']=original_joins
        stats['closed_loops']=stats.get('closed_loops', 0)+circle_count+ellipse_count
        stats['fitted_circles']=circle_count
        stats['fitted_ellipses']=ellipse_count
        result=[]
        for shape_path in circles+ellipses:
            result.append([list(point) for point in shape_path])
        for path in raw:
            arr=np.array(path,dtype=np.float32).reshape(-1,1,2)
            # Preserve intentional closed loops and draw-traversal continuity.
            closed=len(path)>3 and math.dist(path[0],path[-1])<2
            simp=cv2.approxPolyDP(arr,epsilon,closed).reshape(-1,2).tolist()
            if closed and len(simp)>2 and math.dist(simp[0],simp[-1])>1e-6:
                simp.append(simp[0][:])
            if len(simp)>=2:result.append(simp)
    elif mode=='outline':
        # If the *entire* image consists of simple, isolated circular or
        # elliptical rings, use their centerlines even in outline mode. A
        # thick circle must not generate inner+outer strokes and two lifts.
        simple=[]
        if detect_regular:
            outline_sk=skeletonize(binary)
            repaired,joins=repair_skeleton_gaps(outline_sk,gap_px=gap_px)
            fitted,remaining,circles=recognize_circles(repaired)
            fitted_ellipses,remaining,ellipses=recognize_ellipses(remaining)
            if fitted or fitted_ellipses:
                if np.count_nonzero(remaining) < max(4, .012*np.count_nonzero(outline_sk)):
                    simple=fitted+fitted_ellipses
                    stats.update(gap_repairs=joins,fitted_circles=circles,
                                 fitted_ellipses=ellipses,
                                 closed_loops=len(simple))
        if simple:
            result=[[list(point) for point in p] for p in simple]
        else:
            # Morphological closing BEFORE contour detection heals small gaps in
        # antialiased logo boundaries without connecting unrelated large areas.
            if gap_px>0:
                radius=1 if gap_px<=4 else 2
                kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*radius+1,2*radius+1))
                binary=cv2.morphologyEx(binary,cv2.MORPH_CLOSE,kernel)
            contours,_=cv2.findContours(binary,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
            result=[]
            for c in contours:
                if cv2.contourArea(c)<min_area or len(c)<3:continue
                appr=cv2.approxPolyDP(c,epsilon,True).reshape(-1,2)
                if len(appr)<3:continue
                path=appr.tolist()
                path.append(path[0][:])
                result.append(path)
            stats['connected_strokes']=len(result)
    else:raise ValueError('Mode must be outline or centerline')
    stats['connected_strokes']=len(result)
    result.sort(key=lambda p:len(p),reverse=True)
    if len(result)>3500:
        raise ValueError('Image produces too many paths; increase minimum area or use a cleaner image')
    count=sum(len(p) for p in result)
    if count>28000:
        raise ValueError(f'Image produces {count} points; increase simplify or use outline mode')
    if not result:
        raise ValueError('No drawable paths; adjust threshold, invert, noise, or mode')
    return (result,stats) if return_stats else result


def image_to_pixel_paths(data, options, return_stats=False):
    binary=preprocess(data,options)
    paths,stats=extract_paths(binary,options,return_stats=True)
    return (paths,binary.shape,stats) if return_stats else (paths,binary.shape)
