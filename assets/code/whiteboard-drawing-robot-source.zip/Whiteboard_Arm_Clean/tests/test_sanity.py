import math
import unittest

import main as C
from core.geometry import Geometry
from core.motion_plan import RatePlanner
from core.vectorize import image_to_pixel_paths
from core.bspline_path import interpolate_strokes
from core.pi_worker import make_step_wave, PenServo
from PIL import Image, ImageDraw
import io

class TestCleanProject(unittest.TestCase):
    def test_master_settings(self):
        self.assertEqual((C.LINK_1_IN, C.LINK_2_IN), (20.0, 20.0))
        self.assertTrue(C.PEN_SERVO_ENABLED)
        self.assertEqual(C.PEN_SERVO_PULSE_CYCLES, 30)

    def test_linkage_forward_inverse(self):
        g = Geometry(link1=C.LINK_1_IN, link2=C.LINK_2_IN,
                     pulley1=C.MOTOR_1_REDUCTION, pulley2=C.MOTOR_2_REDUCTION,
                     input_radius=C.INPUT_EFFECTIVE_RADIUS_IN,
                     elbow_radius=C.ELBOW_LEVER_RADIUS_IN,
                     secondary_rod_length=C.SECONDARY_ROD_LENGTH_IN)
        g.validate()
        x, y = 24.0, 28.0
        q1, q2 = g.ik(x, y)
        _, tip = g.fk(q1, q2)
        self.assertAlmostEqual(tip[0], x, places=5)
        self.assertAlmostEqual(tip[1], y, places=5)
        pts = g.linkage_points(q1, q2)
        self.assertAlmostEqual(math.dist(pts['A'], pts['B']), C.SECONDARY_ROD_LENGTH_IN, places=4)

    def test_single_circle_tracing(self):
        img = Image.new("RGB", (240, 240), "white")
        d = ImageDraw.Draw(img)
        d.ellipse((35, 35, 205, 205), outline="black", width=6)
        stream = io.BytesIO()
        img.save(stream, format="PNG")
        paths, shape, stats = image_to_pixel_paths(stream.getvalue(),
            {"mode":"centerline", "contrast":1.5, "noise":1,
             "threshold":0, "simplify":1.0, "min_area":12,
             "gap_px":6, "recognize_simple_loops":True}, return_stats=True)
        self.assertEqual(stats["fitted_circles"], 1)
        self.assertEqual(len(paths), 1)

    def test_stepper_wave(self):
        pulses, total, secs = make_step_wave((0,0),(12,-8),0,12,12,0.15)
        self.assertEqual(total, (12,8))
        self.assertTrue(pulses)
        self.assertGreater(secs,0)

    def test_motion_planner(self):
        planner=RatePlanner(650,accel=C.MOTOR_ACCEL,jerk=C.MOTOR_JERK)
        moves=[[5,4,False,24.0,27.0],[10,12,True,24.2,27.1]]
        planner.prepare(moves)
        segments=list(planner.segment((0,0),(5,4),False))
        self.assertTrue(segments)

if __name__ == '__main__':
    unittest.main()
