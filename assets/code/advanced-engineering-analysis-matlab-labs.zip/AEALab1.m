%Advanced engineering analysis Lab 1 calculations


%Problem 2 Part D, MATLAB VERIFICATION
sigma = [120 15 0; 15 35 -20; 0 -20 -55];
[V,D] = eig(sigma);
V = V(:,idx);
principaldirection = V(:,1) 



% %Problem 3 Part E
% syms t
% 
% underdamped       = exp(-3*t) * (cos(4*t) + .75*sin(4*t) );
% criticallydamped  = exp(-5*t) + 5*t*exp(-5*t);
% overdamped        = (25/24)*exp(-t) - (1/24)*exp(-25*t);
% fplot(underdamped, LineWidth=2, Color='blue', LineStyle ='--')
% hold on
% xlim([0 4])
% ylim([-.2 1])
% fplot(criticallydamped, LineWidth=2, Color='red', LineStyle =':')
% fplot(overdamped, LineWidth=2, Color='green')
% hold off
% grid on
% xlabel ('Time (s)')
% ylabel ('Displacement (m)')
% title('Underdamped, Critically Damped, and Overdamped Systems')
% legend 'Underdamped' 'Critically Damped ' ' Overdamped'
% set(findall(gcf,'-property','FontName'),'FontName','Times New Roman')
% set(findall(gcf,'-property','FontSize'),'FontSize',12)