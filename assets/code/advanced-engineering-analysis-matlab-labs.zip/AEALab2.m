%Problem 1
A = [-3 2 0; 2 -5 2; 0 2 -3];
det(A)
eig(A)

c1 = -(2/3);
c2 = 8/3;
c3 = .381;
c1h = -(7/3);
c2h = 8/3;
c3h = .619;

syms  t

%Part c
T = c1*[1; 1; 1]*exp(-t) + c2*[1; 0; -1]*exp(-3*t) + c3*[1; -2; 1] * exp(-7*t) + [7.62; 6.43; 5.95];
T_heater = c1h*[1; 1; 1]*exp(-t) + c2h*[1; 0; -1]*exp(-3*t) + c3h*[1; -2; 1] * exp(-7*t) + [9.05; 8.57; 7.38];

figure
fplot(T(1), [0 4], 'LineWidth', 2)
hold on
fplot(T(2), [0 4], 'LineWidth', 2)
fplot(T(3), [0 4], 'LineWidth', 2)
grid on
xlabel('Time')
ylabel('Temperature')
title('Temperature vs. Time')
legend('Temp of Basement', 'Temp of Main Room', 'Temp of Attic')

%Part D
figure
fplot(T_heater(1), [0 4], 'LineWidth', 2)
hold on
fplot(T_heater(2), [0 4], 'LineWidth', 2)
fplot(T_heater(3), [0 4], 'LineWidth', 2)
grid on
xlabel('Time')
ylabel('Temperature')
title('Temperature vs. Time With Heater in Main Room')
legend('Temp of Basement', 'Temp of Main Room', 'Temp of Attic')

% Problem 3 Part D
% clear; clc; close all
% 
% m=6e5; 
% b=1.9e5;
% k=2.4e5; 
% Cg=.1;
% ag=0; 
% wg=1.1;
% w0=sqrt(k/m); 
% zeta=b/(2*m*w0); 
% beta=wg/w0;
% A=[0 0 1 0; 0 0 0 1; -2 1 -4*zeta 2*zeta; 1 -1 2*zeta -2*zeta];
% 
% [V,D]=eig(A); lambda=diag(D); Vn=V./V(1,:);
% disp('Eigenvalues ='); disp(round(lambda,4))
% disp('Normalized Eigenvectors ='); disp(round(Vn,4))
% 
% idx=find(imag(lambda)>0); [~,n]=sort(imag(lambda(idx)),'descend'); idx=idx(n);
% a1=round(real(lambda(idx(1))),4); w1=round(imag(lambda(idx(1))),4); r1=round(real(Vn(2,idx(1))),4);
% a2=round(real(lambda(idx(2))),5); w2=round(imag(lambda(idx(2))),5); r2=round(real(Vn(2,idx(2))),4);
% 
% syms tau C1 C2 C3 C4 real
% q1=exp(a1*tau)*(C1*cos(w1*tau)+C2*sin(w1*tau));
% q2=exp(a2*tau)*(C3*cos(w2*tau)+C4*sin(w2*tau));
% 
% u1h=q1+q2; u2h=r1*q1+r2*q2;
% u1hp=diff(u1h,tau); u2hp=diff(u2h,tau);
% Xh=[u1h;u2h;u1hp;u2hp];
% 
% disp('u1h ='); disp(vpa(u1h,5))
% disp('u2h ='); disp(vpa(u2h,5))
% disp('u1h'' ='); disp(vpa(u1hp,5))
% disp('u2h'' ='); disp(vpa(u2hp,5))
% 
% %Part e
% syms p1 p2 p3 p4 q1p q2p q3p q4p 
% 
% eq1=-beta*q1p==p3;
% eq2=-beta*q2p==p4;
% eq3=-beta*q3p==-2*p1+p2-4*zeta*p3+2*zeta*p4+beta^2;
% eq4=-beta*q4p==p1-p2+2*zeta*p3-2*zeta*p4+beta^2;
% eq5=beta*p1==q3p;
% eq6=beta*p2==q4p;
% eq7=beta*p3==-2*q1p+q2p-4*zeta*q3p+2*zeta*q4p;
% eq8=beta*p4==q1p-q2p+2*zeta*q3p-2*zeta*q4p;
% 
% S=solve([eq1 eq2 eq3 eq4 eq5 eq6 eq7 eq8],[p1 p2 p3 p4 q1p q2p q3p q4p]);
% P=double([S.p1;S.p2;S.p3;S.p4]); Q=double([S.q1p;S.q2p;S.q3p;S.q4p]);
% 
% Xp=P*sin(beta*tau)+Q*cos(beta*tau);
% 
% %Part F
% S0=solve(subs(Xh+Xp,tau,0)==zeros(4,1),[C1 C2 C3 C4]);
% C=double([S0.C1;S0.C2;S0.C3;S0.C4]);
% 
% disp('C1 C2 C3 C4 ='); disp(round(C,4))
% 
% X=subs(Xh,[C1 C2 C3 C4],C.')+Xp;
% Xfun=matlabFunction(X,'Vars',tau);
% 
% t=linspace(0,600,5000); 
% Xplot=Xfun(w0*t);
% 
% figure
% subplot(2,1,1)
% plot(t,Xplot(1,:),t,Xplot(2,:),'LineWidth',1); grid on
% xlabel('t [s]'); ylabel('Dimensionless Displacement'); legend('u_1','u_2')
% 
% subplot(2,1,2)
% plot(t,Xplot(3,:),t,Xplot(4,:),'LineWidth',1);
% grid on
% xlabel('t [s]'); 
% ylabel('Dimensionless Velocity'); 
% legend('u_1''','u_2''')