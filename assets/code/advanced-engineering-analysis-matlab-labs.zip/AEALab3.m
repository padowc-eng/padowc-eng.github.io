% %Advanced Engineering Analysis Lab 3
% %William Pado
% %Problem 1 Part C
clear
clc
f = @(xi) 1 - xi/6 + xi.^2/180 - xi.^3/12960;

xi_1 = fsolve(f, 8)

figure
fplot(f, [0 20])
yline(0)
grid on
xlabel('\xi')
ylabel('f(\xi)')
xlim([0 20])
title('f(\xi) vs. \xi')
syms q L E I
eqn = xi_1 == (q*L^3)/(E*I);

assume(q > 0 & E > 0 & I > 0)
Lcritical = solve(eqn, L, 'Real', true);
Lcritical = simplify(Lcritical)

%Problem 1 Part D
% Evaluate the critical length for specified parameter values

d = .04; %meters
rho = 7850; %density in kg/m^3
g = 9.81;
E = 200e9; % Young's modulus in Pa
I = (pi*d^4)/64; 
A = (pi*d^2)/4;
q = rho*g*A;


BuckleHeight = (10^(2/3)*175971666333291^(1/3)*E^(1/3)*I^(1/3))/(131072*q^(1/3))%Equation from previous Lcritical Calculation

%Problem 2 Part a
%Calculations
clear 

syms k 
eqn = ( (k-3)*(k-2)*(k-1)*k + 6*(k-2)*(k-1)*k +6*(k-1)*k) == 0;
poly =expand(eqn)
roots([1 0 -1 0 0])

%Problem 2 Part c
figure
constI1 = .1; % P/(EI)
constI2 = .1 / 8; % P/(EI* 8)
syms x
u1(x) = constI1 * (log(x) + 1/x - 1);
u2(x) = constI2 * (log(x) + 1/x - 1);
fplot(u1(x), [1 2])
hold on
fplot(u2(x), [1 2])
legend Displacement-with-I(1) Displacement-with-I(2)
title 'Displacement of Beam along Length with Varying Moments'
xlabel('Position, x')
ylabel('Displacement, u(x)')
grid on
hold off