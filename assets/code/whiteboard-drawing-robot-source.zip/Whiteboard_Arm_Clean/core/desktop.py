"""Simple Windows/macOS/Linux desktop GUI for the Pi whiteboard drawing arm.
Run from VS Code. The Pi worker is transferred and started over SSH automatically.
"""
from __future__ import annotations

import io
import json
import math
import queue
import threading
import time
import uuid
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from PIL import Image, ImageTk, ImageOps
from .geometry import Geometry, optimize_strokes, subdivide, gcode_from_paths
from .vectorize import image_to_pixel_paths
from .motion_plan import RatePlanner, estimate_seconds, format_eta, estimate_pen_seconds
from .bspline_path import interpolate_strokes
from .stroke_continuity import stitch_paths, suppress_micro_lifts
import main as C

HERE = Path(__file__).resolve().parent


class WhiteboardApp:
    def __init__(self, root):
        self.root = root
        self.root.title('Whiteboard Arm')
        self.root.geometry('1190x790')
        self.root.minsize(1010, 700)
        self.events = queue.Queue()
        self.running = False
        self.stop_requested = False
        self.ssh = None
        self.worker_conn = None
        self.worker_stdin = None
        self.remote_stop = None
        self.image_path = None
        self.raw_image = None
        self.paths = []
        self.moves = []
        self.geometry = Geometry(home_y=C.HOME_Y_IN)
        self.position = [0, 0]
        self.pen_down = False
        self.servo_transition_count = 0
        self.last_tip = None
        self.traced = []
        self.job_id = None
        self.photo = None
        self.last_pi_update = None
        self.pi_started_at = None

        self.host = tk.StringVar(value=C.SSH_HOST)
        self.username = tk.StringVar(value=C.SSH_USER)
        self.password = tk.StringVar()
        self.mode = tk.StringVar(value=C.IMAGE_MODE)
        self.quality = tk.StringVar(value='simple line drawing')
        self.board_w = tk.StringVar(value=str(C.BOARD_W_IN))
        self.board_h = tk.StringVar(value=str(C.BOARD_H_IN))
        self.l1 = tk.StringVar(value=str(C.LINK_1_IN))
        self.l2 = tk.StringVar(value=str(C.LINK_2_IN))
        self.ratio1 = tk.StringVar(value=str(C.MOTOR_1_REDUCTION))
        self.ratio2 = tk.StringVar(value=str(C.MOTOR_2_REDUCTION))
        self.input_radius = tk.StringVar(value=str(C.INPUT_EFFECTIVE_RADIUS_IN))
        self.elbow_radius = tk.StringVar(value=str(C.ELBOW_LEVER_RADIUS_IN))
        self.spacing = self.elbow_radius  # one physical J--B distance; no independent cosmetic bar offset
        self.elbow_transfer = tk.StringVar(value=C.ELBOW_TRANSFER)
        self.marker = tk.StringVar(value=str(C.MARKER_DIAMETER_IN))
        self.gap_px = tk.StringVar(value=str(C.IMAGE_GAP_REPAIR_PX))
        self.microsteps = tk.StringVar(value=str(C.MICROSTEPS))
        self.home_y = tk.StringVar(value=str(C.HOME_Y_IN))
        self.max_rate = tk.IntVar(value=int(C.MAX_MOTOR_RATE))
        self.time_text = tk.StringVar(value='Estimated job time: —')
        self.swap_motors = tk.BooleanVar(value=C.SWAP_MOTOR_CHANNELS)
        self.invert1 = tk.BooleanVar(value=C.INVERT_MOTOR_1)
        self.invert2 = tk.BooleanVar(value=C.INVERT_MOTOR_2)
        self.elbow = tk.StringVar(value=f'{C.ELBOW_BRANCH:+d}')
        self.status = tk.StringVar(value='Choose an image to begin. No motors are running.')
        self.position_text = tk.StringVar(value='Joint angles: —')
        self.progress = tk.DoubleVar(value=0)
        self.geometry = self.make_geometry()
        self._ui()
        self.root.after(40, self._events)
        self.root.protocol('WM_DELETE_WINDOW', self._on_close)
        self.draw_board()

    def _field(self, parent, title, var, width=8):
        row = ttk.Frame(parent)
        row.pack(fill='x', pady=2)
        ttk.Label(row, text=title, width=21).pack(side='left')
        ttk.Entry(row, textvariable=var, width=width).pack(side='left', fill='x', expand=True)

    def _ui(self):
        main = ttk.Frame(self.root, padding=14)
        main.pack(fill='both', expand=True)
        left = ttk.Frame(main, width=280)
        left.pack(side='left', fill='y', padx=(0, 14))
        left.pack_propagate(False)
        right = ttk.Frame(main)
        right.pack(side='left', fill='both', expand=True)
        ttk.Label(left, text='WHITEBOARD ARM', font=('Segoe UI', 16, 'bold')).pack(anchor='w', pady=(0, 12))
        ttk.Button(left, text='Choose image', command=self.load_image).pack(fill='x', pady=5, ipady=7)
        self.filename_label = ttk.Label(left, text='No image selected', foreground='#666', wraplength=260)
        self.filename_label.pack(anchor='w', pady=(0, 8))
        options = ttk.Frame(left)
        options.pack(fill='x', pady=(2, 6))
        ttk.Label(options, text='Image style').pack(side='left')
        ttk.Combobox(options, textvariable=self.mode, state='readonly', width=13,
                     values=('centerline', 'outline')).pack(side='right')
        ttk.Button(left, text='Reprocess image', command=self.process_image).pack(fill='x', pady=3)
        ttk.Separator(left).pack(fill='x', pady=14)
        ttk.Label(left, text='RASPBERRY PI', font=('Segoe UI', 10, 'bold')).pack(anchor='w')
        self._field(left, 'Host / IP', self.host, 15)
        self._field(left, 'Username', self.username, 15)
        pwrow = ttk.Frame(left)
        pwrow.pack(fill='x', pady=2)
        ttk.Label(pwrow, text='SSH password', width=21).pack(side='left')
        ttk.Entry(pwrow, textvariable=self.password, show='*', width=12).pack(side='left', fill='x', expand=True)
        ttk.Label(left, text='SSH access must be enabled. Password is not saved.',
                  foreground='#666', wraplength=265).pack(anchor='w', pady=(3, 6))
        ttk.Button(left, text='Arm and motor settings...', command=self.settings_window).pack(fill='x', pady=4)
        ttk.Label(left,text='Motor speed (microsteps/sec, next run)',font=('Segoe UI',9,'bold')).pack(anchor='w',pady=(10,1))
        slider=tk.Scale(left,from_=250,to=2200,resolution=50,orient='horizontal',
                        variable=self.max_rate,command=lambda _x:self.update_time(),
                        showvalue=True,length=260)
        slider.pack(fill='x')
        self.speed_slider=slider
        ttk.Label(left,textvariable=self.time_text,foreground='#3b5266').pack(anchor='w',pady=(0,7))
        ttk.Separator(left).pack(fill='x', pady=14)
        ttk.Button(left, text='Preview only  (no motors)', command=self.preview).pack(fill='x', pady=5, ipady=5)
        ttk.Button(left, text='RUN ON RASPBERRY PI', command=self.start_hardware).pack(fill='x', pady=5, ipady=7)
        ttk.Button(left, text='STOP MOTORS', command=self.stop).pack(fill='x', pady=5, ipady=5)
        ttk.Button(left, text='Save G-code', command=self.save_gcode).pack(fill='x', pady=5)
        ttk.Label(left, text='Defaults from main.py. Edit and restart to keep settings; verify linkage dimensions before hardware.',
                  foreground='#666', wraplength=265).pack(anchor='w', pady=(20, 8))
        ttk.Label(left, text='Align home and belt coupling before running. '
                  f'Pen servo on GPIO {C.PEN_SERVO_GPIO}. Confirm up/down clearance before drawing.',
                  wraplength=265, foreground='#a0442a').pack(anchor='w', pady=(0, 8))
        self.canvas = tk.Canvas(right, bg='#e9eef2', highlightthickness=0)
        self.canvas.pack(fill='both', expand=True)
        self.canvas.bind('<Configure>', lambda e: self.draw_board())
        self.progressbar = ttk.Progressbar(right, maximum=100, variable=self.progress)
        self.progressbar.pack(fill='x', pady=(8, 3))
        ttk.Label(right, textvariable=self.position_text).pack(anchor='w')
        ttk.Label(right, textvariable=self.status, wraplength=680).pack(anchor='w', pady=(4, 0))

    def settings_window(self):
        window=tk.Toplevel(self.root)
        window.title('Arm settings')
        window.geometry('440x745')
        window.transient(self.root)
        frame=ttk.Frame(window,padding=16)
        frame.pack(fill='both',expand=True)
        ttk.Label(frame,text='Geometry / drives',font=('Segoe UI',12,'bold')).pack(anchor='w',pady=(0,10))
        for title,var in [('Board width (in)',self.board_w),('Board height (in)',self.board_h),
                          ('Link 1 (in)',self.l1),('Link 2 (in)',self.l2),
                          ('Motor 1 pulley reduction',self.ratio1),('Motor 2 pulley reduction',self.ratio2),
                          ('Input crank radius O2-A (in)',self.input_radius),
                          ('Forearm pin offset J-B (in)',self.elbow_radius),('Marker diameter (in)',self.marker),
                          ('Home Y (in, top center X)',self.home_y),
                          ('Microsteps (DIP setting)',self.microsteps),
                          ('Reconnect gaps (pixels)',self.gap_px),
                          ]:
            self._field(frame,title,var)
        row=ttk.Frame(frame);row.pack(fill='x',pady=2)
        ttk.Label(row,text='Elbow transfer',width=21).pack(side='left')
        ttk.Combobox(row,textvariable=self.elbow_transfer,state='readonly',width=12,
                     values=('closed_loop',)).pack(side='left')
        ttk.Checkbutton(frame,text='Swap physical M1 / M2 channels',variable=self.swap_motors).pack(anchor='w',pady=3)
        ttk.Checkbutton(frame,text='Invert motor 1 direction',variable=self.invert1).pack(anchor='w',pady=3)
        ttk.Checkbutton(frame,text='Invert motor 2 direction',variable=self.invert2).pack(anchor='w',pady=3)
        row=ttk.Frame(frame);row.pack(fill='x',pady=2)
        ttk.Label(row,text='Elbow branch',width=21).pack(side='left')
        ttk.Combobox(row,textvariable=self.elbow,state='readonly',width=7,values=('+1','-1')).pack(side='left')
        ttk.Label(frame,text='Closed-loop model. Actual rod A-B length, crank-center offsets, and attachment phase are set in main.py. Measure centers in CAD before physical moves.',
                  foreground='#a0442a',wraplength=350).pack(anchor='w',pady=8)
        ttk.Button(frame,text='Apply and reprocess image',command=lambda:(window.destroy(),self.process_image())).pack(fill='x',pady=5)

    def make_geometry(self):
        g = Geometry(board_w=float(self.board_w.get()), board_h=float(self.board_h.get()),
                     link1=float(self.l1.get()), link2=float(self.l2.get()),
                     attachment_spacing=float(self.spacing.get()),
                     pulley1=float(self.ratio1.get()), pulley2=float(self.ratio2.get()),
                     input_radius=float(self.input_radius.get()),
                     elbow_radius=float(self.elbow_radius.get()),
                     secondary_rod_length=C.SECONDARY_ROD_LENGTH_IN,
                     crank_offset_x=C.CRANK_CENTER_DX_IN,
                     crank_offset_y=C.CRANK_CENTER_DY_IN,
                     elbow_pin_phase_deg=C.ELBOW_PIN_PHASE_DEG,
                     elbow_transfer=self.elbow_transfer.get(),
                     swap_motors=self.swap_motors.get(),
                     invert1=self.invert1.get(), invert2=self.invert2.get(),
                     marker_diameter=float(self.marker.get()),
                     microsteps=int(self.microsteps.get()),
                     elbow=int(self.elbow.get()),
                     home_x=float(self.board_w.get())/2, home_y=float(self.home_y.get()))
        g.margin=C.BOARD_MARGIN_IN
        g.motor_steps_per_rev=C.STEPS_PER_MOTOR_REV
        return g.validate()

    def load_image(self):
        path = filedialog.askopenfilename(title='Choose image',
                 filetypes=[('Images','*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.webp'), ('All files','*.*')])
        if not path:
            return
        self.image_path = Path(path)
        self.filename_label.config(text=self.image_path.name)
        self.process_image()

    def process_image(self):
        if self.running:
            return
        if not self.image_path:
            messagebox.showinfo('Choose image', 'Select an image first.')
            return
        try:
            self.status.set('Processing image...')
            self.root.update_idletasks()
            g = self.make_geometry()
            data = self.image_path.read_bytes()
            options = {'mode': self.mode.get(), 'contrast': C.IMAGE_CONTRAST, 'noise': C.IMAGE_NOISE,
                       'threshold': C.IMAGE_THRESHOLD, 'simplify': C.IMAGE_SIMPLIFY_PX, 'min_area': C.IMAGE_MIN_AREA_PX,
                       'gap_px': int(self.gap_px.get()),
                       'recognize_simple_loops': getattr(C,'RECOGNIZE_SIMPLE_LOOPS',True)}
            pixels, image_shape, trace_info = image_to_pixel_paths(data, options, return_stats=True)
            paths, bounds = g.fit_paths(pixels, image_shape)
            # Stitch near-tangent gaps BEFORE ordering, smoothing or motor IK.
            # Small raster breaks therefore cannot become servo lift events.
            paths, connected = stitch_paths(paths, g,
                max_gap_in=getattr(C, 'STROKE_JOIN_GAP_IN', 0.15))
            paths = optimize_strokes(paths)
            # Cubic C2 B-spline interpolation in Cartesian space, before IK.
            # Shared by preview, G-code export and physical motor job.
            paths, spline_count, linear_count = interpolate_strokes(paths, g)
            moves, tiny_lifts = suppress_micro_lifts(
                self.make_moves(g, paths),
                max_gap_in=getattr(C,'PEN_LIFT_IGNORE_GAP_IN',0.06))
            moves = self.compact_moves(moves)
            if len(moves) > 60000:
                raise ValueError('Image is too detailed. Try a simpler image or outline mode.')
            self.geometry, self.paths, self.moves = g, paths, moves
            self.progress.set(0)
            self.traced.clear()
            self.position = [0, 0]
            self.pen_down = False
            self.last_tip = None
            self.draw_board()
            self.update_time()
            pen_cycles=sum(bool(m[2]) and (i==0 or not moves[i-1][2])
                           for i,m in enumerate(moves))
            self.status.set(f'Ready: {len(paths)} pen-down strokes; '
                            f'{pen_cycles} pen-lower/raise cycles; '
                            f'{trace_info.get("closed_loops",0)} single-pass closed outlines; '
                            f'{trace_info["gap_repairs"]} pixel gaps repaired; '
                            f'{connected} additional curve joins; '
                            f'{tiny_lifts} micro-lifts removed; '
                            f'{trace_info.get("fitted_circles",0)} circles, '
                            f'{trace_info.get("fitted_ellipses",0)} ellipses fitted; '
                            f'{spline_count} fitted B-splines, {linear_count} linear fallbacks; '
                            f'{len(moves)} step targets. No deliberate stroke retracing.')
        except Exception as exc:
            self.paths, self.moves = [], []
            self.status.set(f'Image processing failed: {exc}')
            messagebox.showerror('Processing failed', str(exc))

    @staticmethod
    def servo_pause():
        if getattr(C, 'PEN_SERVO_HOLD_PWM', False):
            return C.PEN_SERVO_SETTLE_S
        return max(C.PEN_SERVO_SETTLE_S,
                   getattr(C, 'PEN_SERVO_PULSE_CYCLES', 30) / 50.0 + 0.06)

    def estimated_job_time(self, max_rate):
        motion = estimate_seconds(self.moves, max_rate, **self.motion_settings())
        return motion + estimate_pen_seconds(self.moves, self.servo_pause(),
                                             C.PEN_SERVO_ENABLED)

    def update_time(self):
        try:
            seconds=self.estimated_job_time(int(self.max_rate.get())) if self.moves else 0
            self.time_text.set('Est. motion: '+format_eta(seconds) if self.moves else 'Estimated job time: —')
        except (ValueError,TypeError):
            self.time_text.set('Estimated time unavailable')

    @staticmethod
    def make_moves(g, paths):
        moves=[]
        previous=(g.home_x,g.home_y)
        for path in paths:
            if len(path)<2:
                continue
            start=path[0]
            for x,y in subdivide(*previous,*start,max_in=.25):
                if not g.valid(x,y,g.marker_diameter/2):
                    raise ValueError(f'Unsafe travel coordinate ({x:.2f}, {y:.2f})')
                a,b=g.motor_step_target(x,y)
                moves.append([a,b,False,x,y])
            for x,y in path[1:]:
                for xx,yy in subdivide(*start,x,y,max_in=.19):
                    if not g.valid(xx,yy,g.marker_diameter/2):
                        raise ValueError(f'Unsafe drawing coordinate ({xx:.2f}, {yy:.2f})')
                    a,b=g.motor_step_target(xx,yy)
                    moves.append([a,b,True,xx,yy])
                start=(x,y)
            previous=start
        # Return to the known home pose, pen up
        for x,y in subdivide(*previous,g.home_x,g.home_y,max_in=.25):
            a,b=g.motor_step_target(x,y)
            moves.append([a,b,False,x,y])
        return moves

    @staticmethod
    def compact_moves(moves):
        """Remove repeated quantized targets without erasing pen transitions.

        B-spline samples can round to identical (motor1, motor2) step targets.
        Such zero-step segments make the controller appear frozen and add many
        pointless trajectory junctions. Keep the first/last pen states intact.
        """
        result=[]
        for move in moves:
            if result and move[:3] == result[-1][:3]:
                result[-1] = move
            else:
                result.append(move)
        return result

    @staticmethod
    def motion_settings():
        return {'accel': C.MOTOR_ACCEL, 'jerk': C.MOTOR_JERK,
                'max_centripetal': C.MAX_CENTRIPETAL_IN_S2,
                'detail_radius': C.DETAIL_RADIUS_IN,
                'detail_factor': C.DETAIL_SPEED_FACTOR,
                'travel_factor': C.TRAVEL_SPEED_FACTOR,
                'junction_dev': C.JUNCTION_DEVIATION_STEPS,
                'chunk': C.STEP_CHUNK}

    def convert_steps_to_pose(self, steps):
        g=self.geometry
        h1,h2=g.ik(g.home_x,g.home_y)
        hm1,hm2=g.motor_angles(h1,h2)
        k=g.motor_steps_per_rev*g.microsteps/(2*math.pi)
        m1=hm1+steps[0]/k
        m2=hm2+steps[1]/k
        return g.joints_from_motor_angles(m1,m2)

    def display_pose(self, steps, pen):
        self.position=list(steps)
        q1,q2=self.convert_steps_to_pose(steps)
        _,tip=self.geometry.fk(q1,q2)
        if pen and self.pen_down and self.last_tip:
            self.traced.append((self.last_tip,tip))
            if hasattr(self, '_map_xy'):
                self.canvas.create_line(*self._map_xy(self.last_tip), *self._map_xy(tip),
                                        fill='#1275aa', width=max(2,self.geometry.marker_diameter*self._scale),
                                        tags=('trace',))
            if len(self.traced) > 18000:
                self.traced=self.traced[-18000:]
        self.pen_down=pen
        self.last_tip=tip if pen else None
        self.position_text.set(f'Joint: {math.degrees(q1):+.1f}°, {math.degrees(q2):+.1f}°    '
                               f'Motor steps: {steps[0]:+d}, {steps[1]:+d} (commanded)  '
                               f'Pen: {"DOWN" if pen else "UP"}')
        self._draw_active()

    def draw_board(self):
        c=self.canvas
        c.delete('all')
        g=self.geometry
        w=max(c.winfo_width(), 450)
        h=max(c.winfo_height(), 450)
        scale=min((w-95)/g.board_w,(h-85)/g.board_h)
        x0=(w-g.board_w*scale)/2
        y0=(h-g.board_h*scale)/2+8
        def xy(p):return (x0+p[0]*scale,y0+p[1]*scale)
        x1,y1=xy((0,0));x2,y2=xy((g.board_w,g.board_h))
        c.create_rectangle(x1,y1,x2,y2,fill='white',outline='#98a5b0',width=2)
        c.create_text(x0+g.board_w*scale/2,y0-15,text=f'{g.board_w:g} in',fill='#50606d')
        c.create_text(x0-23,y0+g.board_h*scale/2,text=f'{g.board_h:g} in',angle=90,fill='#50606d')
        # A dotted reachable circle from top center, clipped implicitly by whiteboard
        ox,oy=xy(g.shoulder)
        r=(g.link1+g.link2-g.margin)*scale
        c.create_arc(ox-r,oy-r,ox+r,oy+r,start=180,extent=180,
                     style='arc',outline='#b4c2ca',dash=(4,6))
        for path in self.paths:
            if len(path)<2:continue
            points=[v for point in path for v in xy(point)]
            c.create_line(*points, fill='#c6d5df', width=2, smooth=False)
        for a,b in self.traced:
            c.create_line(*xy(a),*xy(b), fill='#1275aa',width=max(2,g.marker_diameter*scale))
        self._map_xy=xy
        self._scale=scale
        self._draw_active()
        c.create_text(x0+8,y2-10,text='Preview paths: gray  •  Completed: blue',
                      anchor='w',fill='#637784',font=('Segoe UI',9),tags=('legend',))

    def _draw_active(self):
        c=self.canvas
        c.delete('active')
        g=self.geometry
        xy=self._map_xy
        try:
            q1,q2=self.convert_steps_to_pose(self.position)
            elbow, tip=g.fk(q1,q2)
            ox,oy=xy(g.shoulder)
            ex,ey=xy(elbow)
            tx,ty=xy(tip)
            # TRUE mechanism: distinct base crank and elbow attachment points.
            # Rigid lengths O--J, O2--A, A--B, J--B; forearm J--T is rigid.
            pts=g.linkage_points(q1,q2)
            # The primary upper arm rotates with motor 1.
            c.create_line(*xy(pts['O']), *xy(pts['J']), fill='#243e53', width=7,
                          capstyle='round', tags=('active',))
            # The secondary long rod connects crank pin A directly to the
            # rigid forearm attachment B, not to a fake perpendicular offset.
            c.create_line(*xy(pts['A']), *xy(pts['B']), fill='#8198a6', width=6,
                          capstyle='round', tags=('active',))
            # Small input crank from its rotation center O2 to A.
            c.create_line(*xy(pts['O2']), *xy(pts['A']), fill='#65849a', width=4,
                          capstyle='round', tags=('active',))
            # Rigid forearm J->T and attachment lever J->B (may be off-axis
            # if elbow pin phase is configured nonzero).
            c.create_line(*xy(pts['J']), *xy(pts['T']), fill='#3185b8', width=7,
                          capstyle='round', tags=('active',))
            c.create_line(*xy(pts['J']), *xy(pts['B']), fill='#3185b8', width=5,
                          capstyle='round', tags=('active',))
            for key,rr,fill in [('O',7,'#223b52'),('A',4,'#637989'),
                                ('J',5,'#1f749e'),('B',4,'#5b95b4'),('T',5,'#e26c35')]:
                px,py=xy(pts[key])
                c.create_oval(px-rr,py-rr,px+rr,py+rr,fill=fill,
                              outline='white',width=1,tags=('active',))
        except Exception:
            pass

    def save_gcode(self):
        if not self.paths:
            messagebox.showinfo('No image','Choose and process an image first.')
            return
        path=filedialog.asksaveasfilename(title='Save G-code',defaultextension='.gcode',
                                          filetypes=[('G-code','*.gcode')])
        if path:
            Path(path).write_text(gcode_from_paths(self.paths),encoding='utf-8')
            self.status.set('Saved G-code to '+path)

    def preview(self):
        if self.running:return
        if not self.moves:
            messagebox.showinfo('No image','Choose an image first.')
            return
        self.running=True
        self.speed_slider.configure(state='disabled')
        self.stop_requested=False
        self.preview_cancel=threading.Event()
        self.progress.set(0)
        self.traced.clear();self.last_tip=None
        self.position = [0, 0]; self.pen_down = False
        self.status.set('Previewing at selected motor speed (no Pi or motors).')
        threading.Thread(target=self._preview_thread,daemon=True).start()

    def _preview_thread(self):
        try:
            planner=RatePlanner(self.max_rate.get(),**self.motion_settings())
            previous_pen = False
            planner.prepare(self.moves)
            total=len(self.moves)
            before=(0,0)
            last_update=0.0
            for i,item in enumerate(self.moves):
                if self.stop_requested:break
                if C.PEN_SERVO_ENABLED and bool(item[2]) != previous_pen:
                    if self.preview_stop_wait(self.servo_pause()):
                        break
                previous_pen = bool(item[2])
                target=(int(item[0]),int(item[1]))
                delta=[target[k]-before[k] for k in (0,1)]
                for end,count,counts,dt in planner.segment(before,target,bool(item[2])):
                    if self.stop_requested:break
                    if dt>0 and self.preview_stop_wait(dt):break
                    pos=[before[k]+(1 if delta[k]>=0 else -1)*
                         ((end*abs(delta[k]))//count) for k in (0,1)]
                    now=time.monotonic()
                    if now-last_update>=.035:
                        self.events.put({'type':'position','steps':pos,'pen':bool(item[2]),
                                         'completed':i,'total':total})
                        last_update=now
                if self.stop_requested:break
                before=target
            if not self.stop_requested:
                self.events.put({'type':'position','steps':list(before),'pen':False,
                                 'completed':total,'total':total})
            self.events.put({'type':'stopped' if self.stop_requested else 'finished'})
        except Exception as exc:
            self.events.put({'type':'error','message':str(exc)})

    def preview_stop_wait(self,seconds):
        # interruptible wait; no artificial 25ms per image point
        return self.preview_cancel.wait(seconds)

    def start_hardware(self):
        if self.running:return
        if not self.moves:
            messagebox.showinfo('No image','Choose and process an image first.')
            return
        try:
            current=self.make_geometry()
            if current!=self.geometry:
                messagebox.showwarning('Settings changed','Click Reprocess image before running.')
                return
            max_rate=int(self.max_rate.get())
            if not 250<=max_rate<=2200:
                raise ValueError('Max rate must be 250–2200 steps/s')
        except Exception as exc:
            messagebox.showerror('Invalid settings',str(exc));return
        if not messagebox.askyesno('Physical home / safety confirmation',
                'ARM MUST BE PHYSICALLY ALIGNED TO THE DISPLAYED HOME POSE.\n\n'
                'Have you confirmed BOTH motor zeros and the belt coupling, '
                'verified servo rotation, clearance, and that the arm cannot fall or collide?\n\n'
                'The Pi does NOT have encoders, limits, or an emergency stop. '
                'Click YES only if you have calibrated the mechanism.'):
            return
        self.running=True
        self.speed_slider.configure(state='disabled')
        self.stop_requested=False
        self.traced.clear();self.last_tip=None
        self.pen_down = False
        self.position=[0,0]
        self.progress.set(0)
        self.status.set('Connecting to Pi... Job time ≈ '+format_eta(self.estimated_job_time(max_rate)))
        self.last_pi_update = time.monotonic()
        self.pi_started_at = None
        job={'moves':self.moves,'max_rate':max_rate,**self.motion_settings(),
             'microsteps':self.geometry.microsteps,
             'servo': {'enabled': C.PEN_SERVO_ENABLED, 'gpio': C.PEN_SERVO_GPIO,
                       'up_us': C.PEN_UP_PULSE_US, 'down_us': C.PEN_DOWN_PULSE_US,
                       'settle_s': C.PEN_SERVO_SETTLE_S,
                       'hold_pwm': getattr(C, 'PEN_SERVO_HOLD_PWM', False),
                       'pulse_cycles': getattr(C, 'PEN_SERVO_PULSE_CYCLES', 30)},
             'notes':'Motor axes aligned at home; servo positions calibrated independently'}
        self.job_id=uuid.uuid4().hex
        credentials=(self.host.get().strip(),self.username.get().strip(),self.password.get())
        image_file=self.image_path
        threading.Thread(target=self._ssh_worker,args=(job,self.job_id,credentials,image_file),daemon=True).start()

    def _ssh_worker(self,job,job_id,credentials,image_file):
        import paramiko
        conn=None
        try:
            conn=paramiko.SSHClient()
            conn.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            host, username, pw = credentials
            conn.connect(host,username=username,
                         password=pw or None,look_for_keys=(not bool(pw)),
                         allow_agent=(not bool(pw)),timeout=10,auth_timeout=10)
            self.worker_conn=conn
            _,stdout,stderr=conn.exec_command('mkdir -p ~/.whiteboard_arm/jobs',timeout=10)
            if stdout.channel.recv_exit_status()!=0:
                raise RuntimeError(stderr.read().decode(errors='replace'))
            sftp=conn.open_sftp()
            remote_dir=conn.exec_command('printf %s "$HOME"')[1].read().decode().strip()
            if not remote_dir.startswith('/'):
                raise RuntimeError('Could not resolve Pi home directory')
            remote_dir += '/.whiteboard_arm'
            remote_job=f'{remote_dir}/jobs/{job_id}.json'
            self.remote_stop=f'{remote_dir}/jobs/{job_id}.stop'
            sftp.put(str(HERE/'pi_worker.py'),f'{remote_dir}/pi_worker.py')
            sftp.put(str(HERE/'motion_plan.py'),f'{remote_dir}/motion_plan.py')
            # Keep the original uploaded image on the Pi alongside the drawing job.
            if image_file is not None:
                suffix=image_file.suffix.lower()
                if suffix not in ('.png','.jpg','.jpeg','.bmp','.tif','.tiff','.webp'):
                    suffix='.img'
                sftp.put(str(image_file), f'{remote_dir}/jobs/{job_id}{suffix}')
            with sftp.file(remote_job, 'w') as remote_file:
                remote_file.write(json.dumps(job).encode('utf-8'))
            sftp.close()
            cmd=f'/usr/bin/python3 -u {remote_dir}/pi_worker.py --job {remote_job} --stop {self.remote_stop}'
            if self.stop_requested:
                self.events.put({'type':'stopped','steps':[0,0]})
                return
            stdin,stdout,stderr=conn.exec_command(cmd,get_pty=False)
            self.worker_stdin=stdin
            if self.stop_requested:
                stdin.write('STOP\n');stdin.flush()
            for line in stdout:
                try:
                    data=json.loads(line)
                    self.events.put(data)
                except json.JSONDecodeError:
                    self.events.put({'type':'message','message':line.strip()})
            exit_code=stdout.channel.recv_exit_status()
            errors=stderr.read().decode(errors='replace').strip()
            if exit_code:
                self.events.put({'type':'error','message':errors[-600:] or f'Pi worker exited {exit_code}'})
        except Exception as exc:
            self.events.put({'type':'error','message':f'{type(exc).__name__}: {exc}'})
        finally:
            if conn:conn.close()
            self.worker_conn=None
            self.worker_stdin=None

    def stop(self):
        if not self.running:return
        self.stop_requested=True
        if hasattr(self,'preview_cancel'):
            self.preview_cancel.set()
        self.status.set('STOP sent. Awaiting Pi confirmation; use physical power cutoff in an emergency.')
        # Same SSH session, avoids connecting/authenticating a second SSH client.
        # Interrupts the Pi's stepper enables on receipt, typically limited by LAN latency.
        if self.worker_stdin is not None:
            threading.Thread(target=self._send_stop_command,daemon=True).start()
        elif self.worker_conn is None:
            # If the upload has not started yet, the SSH worker sees stop_requested.
            return
        else:
            # Connection may be ready before the worker process starts;
            # the worker sends STOP immediately after exec_command in that case.
            pass

    def _send_stop_command(self):
        try:
            stream=self.worker_stdin
            if stream is not None:
                stream.write('STOP\n')
                stream.flush()
        except Exception as exc:
            self.events.put({'type':'message',
                             'message':f'Network STOP failed ({exc}). Cut motor power if unsafe.'})

    def _events(self):
        try:
            while True:
                data=self.events.get_nowait()
                kind=data.get('type')
                if kind=='servo':
                    self.servo_transition_count = int(data.get('transitions',0))
                    self.status.set('Pi servo: '+data.get('detail','Position change')+
                                    f' | transitions: {self.servo_transition_count}')
                elif kind=='position':
                    self.last_pi_update = time.monotonic()
                    self.display_pose(data['steps'],data.get('pen',False))
                    completed=data.get('completed',0)
                    total=max(1,data.get('total',1))
                    self.progress.set(100*completed/total)
                    if not self.stop_requested:
                        self.status.set(f'Motion: {completed}/{total} points. '+self.time_text.get()+
                                        f' | Servo changes: {self.servo_transition_count}' +
                                        ' | Animation shows Pi-reported steps, not encoders.')
                elif kind=='started':
                    self.pi_started_at = time.monotonic()
                    self.last_pi_update = self.pi_started_at
                    self.status.set('Pi motor worker started at '+str(data.get('rate','?'))+
                                    ' microsteps/sec. Est. '+format_eta(data.get('estimate',0)))
                elif kind=='heartbeat':
                    self.last_pi_update = time.monotonic()
                    # Do not pretend the arm moved. This signals the worker is
                    # alive, but the current motor-step burst is still running.
                    self.status.set('Pi responsive but no new steps reported: '
                                    +data.get('detail','pulse processing')+
                                    '. If motion seems stuck, the worker will timeout.')
                elif kind in ('finished','stopped','error'):
                    self.running=False
                    self.speed_slider.configure(state='normal')
                    self.remote_stop=None
                    if kind=='finished':
                        self.progress.set(100)
                        self.status.set('Finished. Motor drivers are disabled.')
                    elif kind=='stopped':
                        reason=data.get('reason') or ('STOP pressed in desktop' if self.stop_requested else 'Unknown stop reason')
                        self.status.set(f'Stopped: {reason}. Outputs disabled; re-home before moving again.')
                    else:
                        self.status.set('ERROR: '+str(data.get('message','unknown error')))
                        messagebox.showerror('Motion error',str(data.get('message','unknown error')))
                elif kind=='message':self.status.set(str(data.get('message')))
        except queue.Empty:
            pass
        # Distinguish a frozen connection from deliberately slow step motion.
        if (self.running and self.pi_started_at is not None
                and self.last_pi_update is not None
                and time.monotonic()-self.last_pi_update > 5
                and not self.stop_requested):
            delay = int(time.monotonic()-self.last_pi_update)
            self.status.set(f'No update from Pi for {delay}s. '
                            'Connection or worker may be stalled. STOP if unsafe.')
        self.root.after(40,self._events)

    def _on_close(self):
        if self.running:
            messagebox.showwarning('Job running','Press STOP and wait for confirmation before closing.')
            return
        self.root.destroy()


def launch():
    root = tk.Tk()
    ttk.Style(root).theme_use('clam')
    WhiteboardApp(root)
    root.mainloop()

