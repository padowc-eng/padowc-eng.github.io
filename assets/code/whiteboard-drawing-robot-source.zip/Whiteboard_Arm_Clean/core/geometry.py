"""Geometry, fitting and G-code for a top-mounted planar 2R marker arm.
Coordinates: inches; whiteboard x-right, y-down; shoulder at (board_w / 2, 0).
q1 = first-link angle from +x (clockwise on the drawn board); q2 = relative elbow angle.
"""
import math
from dataclasses import dataclass

MM_PER_IN = 25.4

@dataclass
class Geometry:
    board_w: float = 48.0
    board_h: float = 60.0
    link1: float = 20.0
    link2: float = 20.0
    attachment_spacing: float = 3.0  # visualization only, not effective pen tool offset
    pulley1: float = 4.0
    pulley2: float = 4.0
    coupling: float = 0.0  # deprecated legacy field, unused in differential model
    input_radius: float = 3.0  # input crank pin radius from the coaxial shoulder center [in]
    elbow_radius: float = 3.0  # rigid FOREARM distance from elbow J to second rod pin B [in]
    secondary_rod_length: float = 20.0  # physical length of pinned secondary connecting rod A--B [in]
    crank_offset_x: float = 0.0  # second crank rotation center offset relative to shoulder O
    crank_offset_y: float = 0.0
    elbow_pin_phase_deg: float = 0.0  # attachment B relative to forearm pointing to marker
    elbow_transfer: str = 'closed_loop'  # rigid two-rod closure (no approximate scaling)
    swap_motors: bool = False  # swap assignment of motor 1 and motor 2 hardware channels
    invert1: bool = False
    invert2: bool = False
    elbow: int = 1  # +1 or -1
    margin: float = 1.5
    marker_diameter: float = 0.25
    microsteps: int = 8
    motor_steps_per_rev: int = 200
    home_x: float = 24.0
    home_y: float = 30.0

    def validate(self):
        assert 5 <= self.board_w <= 120 and 5 <= self.board_h <= 120, 'Invalid whiteboard size'
        assert 1 <= self.link1 <= 60 and 1 <= self.link2 <= 60, 'Invalid arm lengths'
        assert 0 <= self.attachment_spacing <= 12, 'Invalid attachment spacing'
        assert 0.2 <= self.pulley1 <= 20 and 0.2 <= self.pulley2 <= 20, 'Invalid pulley ratios'
        assert 0.05 <= self.input_radius <= 12, 'Invalid input pulley radius'
        assert 0.05 <= self.elbow_radius <= 12, 'Invalid elbow lever radius'
        assert self.secondary_rod_length > 0, 'Secondary rod length must be positive'
        assert self.elbow_transfer == 'closed_loop', 'v11 uses rigid closed-loop linkage, not arc-ratio approximations'
        assert self.elbow in (-1, 1), 'Invalid elbow side'
        assert self.microsteps in (1,2,4,8,16,32), 'Invalid microstepping setting'
        assert 0.05 <= self.marker_diameter <= 2, 'Invalid marker diameter'
        assert 0.5 <= self.margin <= 8, 'Invalid margin'
        hq1,hq2=self.ik(self.home_x,self.home_y)
        hm1,hm2=self.motor_angles(hq1,hq2)
        rq1,rq2=self.joints_from_motor_angles(hm1,hm2)
        assert abs(self._wrap_delta(hq1,rq1))<1e-5 and abs(self._wrap_delta(hq2,rq2))<1e-5, 'Configured rod lengths/pin positions cannot reproduce home pose on selected assembly branch'
        assert self.valid(self.home_x,self.home_y), 'Home must be within safe reachable whiteboard area'
        return self

    @property
    def shoulder(self): return (self.board_w/2,0.0)

    def ik(self, x, y):
        dx,dy = float(x)-self.board_w/2,float(y)
        d2=dx*dx+dy*dy
        c2=(d2-self.link1**2-self.link2**2)/(2*self.link1*self.link2)
        if c2 > 1+1e-8 or c2 < -1-1e-8:
            raise ValueError(f'Unreachable point ({x:.2f}, {y:.2f}) in')
        c2=max(-1.0,min(1.0,c2))
        q2=self.elbow*math.acos(c2)
        q1=math.atan2(dy,dx)-math.atan2(self.link2*math.sin(q2),self.link1+self.link2*math.cos(q2))
        return q1,q2

    def fk(self,q1,q2):
        ex=self.shoulder[0]+self.link1*math.cos(q1)
        ey=self.link1*math.sin(q1)
        tipx=ex+self.link2*math.cos(q1+q2)
        tipy=ey+self.link2*math.sin(q1+q2)
        return (ex,ey),(tipx,tipy)

    def valid(self,x,y, pad=0):
        r=math.hypot(x-self.board_w/2,y)
        inner=abs(self.link1-self.link2)+0.5
        outer=self.link1+self.link2-self.margin
        clearance=self.margin+pad
        return (clearance <= x <= self.board_w-clearance and
                clearance <= y <= self.board_h-clearance and
                inner <= r <= outer)

    @staticmethod
    def _unit(angle):
        return math.cos(angle), math.sin(angle)

    @staticmethod
    def _circle_intersections(c0, r0, c1, r1):
        """Return two rigid-link solutions; raise on impossible assembly."""
        dx,dy=c1[0]-c0[0],c1[1]-c0[1]
        d=math.hypot(dx,dy)
        if d < 1e-10 or d > r0+r1+1e-8 or d < abs(r0-r1)-1e-8:
            raise ValueError('Mechanical linkage cannot close at this position. Check rod and pivot dimensions.')
        d=max(d,1e-10)
        a=(r0*r0-r1*r1+d*d)/(2*d)
        h2=r0*r0-a*a
        if h2 < -1e-7: raise ValueError('Linkage closure failed')
        h=math.sqrt(max(0.0,h2)); ux,uy=dx/d,dy/d
        cx,cy=c0[0]+a*ux,c0[1]+a*uy
        return ((cx-h*uy,cy+h*ux),(cx+h*uy,cy-h*ux))

    @staticmethod
    def _dist2(a,b):
        return (a[0]-b[0])**2+(a[1]-b[1])**2

    @staticmethod
    def _wrap_delta(a,b):
        return (a-b+math.pi)%(2*math.pi)-math.pi

    @property
    def crank_center(self):
        return (self.shoulder[0]+self.crank_offset_x,
                self.shoulder[1]+self.crank_offset_y)

    def _elbow_and_pin(self,q1,q2):
        J,_=self.fk(q1,q2)
        theta=q1+q2
        ux,uy=self._unit(theta+math.radians(self.elbow_pin_phase_deg))
        B=(J[0]+self.elbow_radius*ux,J[1]+self.elbow_radius*uy)
        return J,B

    def _drive_crank_point(self,q1,q2):
        """Solve the actual rod loop for A, given shoulder and forearm angles.

        O2--A has length input_radius and A--B has length secondary_rod_length.
        Select the assembly branch closest to an ideal parallelogram.
        """
        _,B=self._elbow_and_pin(q1,q2)
        candidates=self._circle_intersections(self.crank_center,self.input_radius,
                                               B,self.secondary_rod_length)
        theta=q1+q2+math.radians(self.elbow_pin_phase_deg)
        ux,uy=self._unit(theta)
        ideal=(self.crank_center[0]+self.input_radius*ux,
               self.crank_center[1]+self.input_radius*uy)
        return min(candidates,key=lambda a:self._dist2(a,ideal))

    def linkage_points(self,q1,q2):
        """Exact rigid geometric points shown on the whiteboard animation.

        O: shoulder, A: input crank pin, J: primary link elbow,
        B: forearm's separate secondary-rod pin, T: marker tip.
        """
        J,T=self.fk(q1,q2)
        _,B=self._elbow_and_pin(q1,q2)
        A=self._drive_crank_point(q1,q2)
        return dict(O=self.shoulder,O2=self.crank_center,A=A,J=J,B=B,T=T)

    def motor_angles(self,q1,q2):
        """Inverse linkage + pulley mapping: desired tip pose -> motor shafts.

        Motor 1 drives shoulder O--J. Motor 2 rotates crank O2--A.
        The second rod A--B is a rigid *20in* connecting rod, not a
        relative-angle lever approximation. Two-circle intersection solves A.
        """
        A=self._drive_crank_point(q1,q2)
        phi=math.atan2(A[1]-self.crank_center[1],A[0]-self.crank_center[0])
        # Keep phi near the expected absolute forearm direction (unwrap).
        reference=q1+q2+math.radians(self.elbow_pin_phase_deg)
        phi=reference+self._wrap_delta(phi,reference)
        m1=self.pulley1*q1*(-1 if self.invert1 else 1)
        m2=self.pulley2*phi*(-1 if self.invert2 else 1)
        return (m2,m1) if self.swap_motors else (m1,m2)

    def joints_from_motor_angles(self,m1,m2):
        """Forward CLOSED-LOOP motor-to-joints model, not 2R visualization.

        Solve B as intersection of circle(center=J, radius=JB) and
        circle(center=A, radius=AB). Choose assembly branch near the
        parallel-rod state and reject singular/impossible link positions.
        """
        if self.swap_motors:m1,m2=m2,m1
        q1=(m1/self.pulley1)*(-1 if self.invert1 else 1)
        phi=(m2/self.pulley2)*(-1 if self.invert2 else 1)
        ux,uy=self._unit(phi)
        A=(self.crank_center[0]+self.input_radius*ux,
           self.crank_center[1]+self.input_radius*uy)
        J,_=self.fk(q1,0.0)
        points=self._circle_intersections(J,self.elbow_radius,A,self.secondary_rod_length)
        # Physical assembly configuration near the CAD's parallelogram.
        expected=(J[0]+self.elbow_radius*ux,J[1]+self.elbow_radius*uy)
        B=min(points,key=lambda b:self._dist2(b,expected))
        theta=math.atan2(B[1]-J[1],B[0]-J[0])-math.radians(self.elbow_pin_phase_deg)
        # Output relative elbow angle, wrapped into standard IK branch range.
        q2=self._wrap_delta(theta,q1)
        return q1,q2

    def motor_step_target(self,x,y):
        q1,q2=self.ik(x,y)
        hq1,hq2=self.ik(self.home_x,self.home_y)
        m1,m2=self.motor_angles(q1,q2)
        hm1,hm2=self.motor_angles(hq1,hq2)
        k=self.motor_steps_per_rev*self.microsteps/(2*math.pi)
        return (round((m1-hm1)*k), round((m2-hm2)*k))

    def fit_paths(self, pixel_paths, image_shape):
        # pixel_paths is a list of strokes in original image pixels; fit into
        # biggest reachable centered rectangle, preserving the full image aspect.
        h,w=image_shape
        aspect=w/max(h,1)
        pad=self.marker_diameter/2
        best=None
        max_width=self.board_w-2*(self.margin+pad)
        max_height=self.board_h-2*(self.margin+pad)
        for cy_index in range(30, 401):
            cy=cy_index/10
            for j in range(1,501):
                hh=max_height*j/500
                ww=hh*aspect
                if ww>max_width: break
                xl=(self.board_w-ww)/2
                xr=(self.board_w+ww)/2
                yt=cy-hh/2
                yb=cy+hh/2
                if not (self.valid(xl,yt,pad) and self.valid(xr,yt,pad) and
                        self.valid(xl,yb,pad) and self.valid(xr,yb,pad) and
                        self.valid(self.board_w/2,yt,pad)):
                    continue
                if best is None or ww*hh>best[0]: best=(ww*hh,ww,hh,cy)
        if best is None: raise ValueError('No usable drawing rectangle for these arm lengths/board margins')
        _,ww,hh,cy=best
        left=(self.board_w-ww)/2
        top=cy-hh/2
        strokes=[]
        for p in pixel_paths:
            out=[(round(left+float(x)/max(w-1,1)*ww,5),round(top+float(y)/max(h-1,1)*hh,5)) for x,y in p]
            if len(out)>=2: strokes.append(out)
        return strokes, {'x':left,'y':top,'width':ww,'height':hh,'center_y':cy}


def optimize_strokes(strokes):
    # Nearest-endpoint greedy order, reversing open strokes only.
    todo=[p[:] for p in strokes if len(p)>=2]
    ordered=[]
    pos=None
    while todo:
        if pos is None:
            i= max(range(len(todo)), key=lambda j: len(todo[j]))
            rev=False
        else:
            choices=[]
            for j,path in enumerate(todo):
                a=(path[0][0]-pos[0])**2+(path[0][1]-pos[1])**2
                b=(path[-1][0]-pos[0])**2+(path[-1][1]-pos[1])**2
                is_closed=math.dist(path[0],path[-1])<0.01
                choices.append((a,j,False))
                if not is_closed: choices.append((b,j,True))
            _,i,rev=min(choices)
        path=todo.pop(i)
        if rev:path.reverse()
        ordered.append(path)
        pos=path[-1]
    return ordered


def gcode_from_paths(paths, travel_feed=1600, drawing_feed=500):
    lines=['; Whiteboard Arm G-code (custom M3/M5 marker commands)',
           'G21 ; millimeters','G90 ; absolute coordinates','M5 ; marker up']
    for path in paths:
        if len(path)<2:continue
        x,y=path[0]
        lines.append(f'G0 X{x*MM_PER_IN:.3f} Y{y*MM_PER_IN:.3f} F{travel_feed:.1f}')
        lines.append('M3 ; marker down')
        for x,y in path[1:]:
            lines.append(f'G1 X{x*MM_PER_IN:.3f} Y{y*MM_PER_IN:.3f} F{drawing_feed:.1f}')
        lines.append('M5 ; marker up')
    lines.append('M2 ; end')
    return '\n'.join(lines)+'\n'


def parse_gcode(source):
    # Strict subset; refuse unsupported commands rather than silently executing.
    result=[]
    x=y=None
    drawing=False
    units=25.4
    absolute=True
    for lineno,line in enumerate(source.splitlines(),1):
        line=line.split(';')[0].strip().upper()
        if not line:continue
        import re
        words=re.findall(r'([A-Z])\s*([-+]?(?:\d*\.\d+|\d+\.?\d*))',line)
        if not words:continue
        commands={k:float(v) for k,v in words}
        if 'G' in commands:
            g=int(commands['G'])
            if g==20: units=1.0
            elif g==21:units=25.4
            elif g==90:absolute=True
            elif g==91:raise ValueError('G91 incremental mode is not supported')
            elif g in (0,1):
                if not absolute:raise ValueError('Absolute motion required')
                nx=commands.get('X', None)
                ny=commands.get('Y', None)
                if nx is not None:x=nx/units
                if ny is not None:y=ny/units
                if x is None or y is None:raise ValueError(f'Line {lineno}: first move needs both X and Y')
                result.append(('move', x,y,g==1 and drawing, commands.get('F',None)))
            else:raise ValueError(f'Unsupported G-code G{g} at line {lineno}')
        if 'M' in commands:
            m=int(commands['M'])
            if m==3: drawing=True;result.append(('pen',True))
            elif m==5:drawing=False;result.append(('pen',False))
            elif m in (2,30):pass
            else:raise ValueError(f'Unsupported M-code M{m} at line {lineno}')
    if len(result)>120000:raise ValueError('Too many commands')
    return result


def subdivide(x0,y0,x1,y1,max_in=0.12):
    count=max(1,math.ceil(math.hypot(x1-x0,y1-y0)/max_in))
    for i in range(1,count+1):
        f=i/count
        yield x0+(x1-x0)*f,y0+(y1-y0)*f
